CARROWMONT GSEO1E — LEARN SEARCH-INTENT REFINEMENT

Baseline: Source Snapshot 57 (2026-10-13)
Expected Publisher output: 2 PRs
Merge order:
  1. draw004.github.io
  2. carrowmont-qa (last)

Main-site scope:
  - asset-allocation-explained.html
  - zero-based-budgeting.html
  - diversification-across-asset-classes.html
  - emergency-fund-how-much.html
  - how-much-should-i-invest-each-month.html
  - sitemap.xml
  - docs/CARROWMONT_GSEO1E_LEARN_SEARCH_INTENT_REFINEMENT_SPEC.md

QA scope:
  - scripts/source-contract.mjs
  - tests/20-gseo1e-learn-search-intent.spec.js

Locked: no calculator math, calculator UI/localization, reports, canonical URLs, homepage core-tool composition, Mortgage product status or workflow changes.

Validation before packaging:
  - source contract: 390 PASS / 0 FAIL
  - Guard-layout source contract simulation: 390 PASS / 0 FAIL
  - changed Learn titles/descriptions remain inside the existing BING-SEO2 length contract
  - one H1 and parseable JSON-LD per changed Learn page
  - sitemap XML and GSEO1E lastmods validated
  - JavaScript syntax checks pass
