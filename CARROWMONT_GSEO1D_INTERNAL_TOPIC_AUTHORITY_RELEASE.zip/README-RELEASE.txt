CARROWMONT GSEO1D — INTERNAL TOPIC AUTHORITY

Baseline: Source Snapshot 56
Release ID: gseo1d-internal-topic-authority-v1

Purpose:
- Add exactly one contextual primary-tool handoff to each eligible Learn hub planning category.
- Preserve one primary internal destination per calculator intent instead of link dumping.
- Strengthen the Mortgage Decision Centre authority path by connecting the Learn hub, Decision Centre and mortgage prepayment-vs-investing explainer.
- Preserve all calculator mathematics, localization, reports, search-facing titles/descriptions/H1s, canonical URLs and the seven-core-tool homepage.

Expected Publisher output: 3 PRs.
Approved merge order:
1. mortgage-payoff-calculator
2. draw004.github.io
3. carrowmont-qa (last)

Post-merge gate: Pages -> Automated QA -> Multi-Repo Guard -> fresh Source Snapshot.
