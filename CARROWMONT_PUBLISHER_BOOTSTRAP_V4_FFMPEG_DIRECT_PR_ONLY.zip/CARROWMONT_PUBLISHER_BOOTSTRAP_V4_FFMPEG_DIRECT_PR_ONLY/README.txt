CARROWMONT PUBLISHER BOOTSTRAP V4 - FFMPEG DIRECT PR ONLY

Purpose
-------
Fix the Publisher infrastructure failure observed in Batch 8A where Playwright could launch
runner-provided Google Chrome but browserContext.newPage failed because Playwright's bundled
FFmpeg binary was absent.

Why this is safe
----------------
- Changes exactly one workflow file.
- Keeps runner-provided Google Chrome and the existing chrome-desktop QA project.
- Keeps video: retain-on-failure, trace, screenshots, PDF QA and all PASS/FAIL gates.
- Does NOT use playwright install --with-deps chrome.
- Does NOT call apt or azure.archive.ubuntu.com.
- Installs only Playwright FFmpeg, with 3 bounded attempts.
- Persistent FFmpeg provisioning failure remains RED and is labelled PUBLISHER INFRASTRUCTURE FAILURE.
- No site, calculator, formula, responsive, authentication, Supabase, Brevo or Batch 8A file changes.

Deployment
----------
Do NOT run this ZIP through Publisher. Publisher cannot publish a repair to the workflow that is
currently executing.

Create a temporary branch from main, replace only:
.github/workflows/carrowmont-batch-pr-publisher.yml
with the file in this package, commit, open a one-file PR to main, review and merge.

After merge run normal QA, Multi Repo Guard and Source Snapshot. Then rerun the SAME Batch 8A V1
release ZIP through the normal Publisher. Do not rebuild Batch 8A for this infrastructure failure.
