import fs from 'node:fs';
import path from 'node:path';
import { test, expect } from '@playwright/test';
import { tools, standardDownloadMessage } from '../qa.config.js';
import { gotoClean, setInput, installCanvasTextProbe, getCanvasText, validatePdfDownload } from '../helpers/common.js';
import { prepareToolForQa, chooseUnitedStatesLocale } from '../helpers/fixtures.js';


async function dismissAnalyticsConsent(page) {
  const banner = page.locator('#carrowmontAnalyticsConsent');
  if (!(await banner.count())) return;
  if (!(await banner.isVisible().catch(() => false))) return;
  const decline = banner.locator('[data-analytics-choice="denied"]');
  if (await decline.count()) await decline.click();
  await banner.waitFor({ state: 'detached', timeout: 3000 }).catch(() => {});
}

function savePdfArtifact(info, name) {
  const dir = path.resolve('qa-artifacts', 'pdfs');
  fs.mkdirSync(dir, { recursive: true });
  const safe = String(name).replace(/[^a-z0-9._-]+/gi, '-').toLowerCase();
  fs.copyFileSync(info.filePath, path.join(dir, `${safe}.pdf`));
}

async function seedBudgetSs2History(page) {
  const months = ['2026-07','2026-08','2026-09'].map(month => ({
    month,
    monthExceptional: false,
    flexible: [
      { id:`groceries-${month}`, name:'Groceries', amount:15000, frequency:'monthly', protected:true, exceptional:false, dueDate:'' },
      { id:`dining-${month}`, name:'Dining & entertainment', amount:5000, frequency:'monthly', protected:false, exceptional:false, dueDate:'' },
      { id:`shopping-${month}`, name:'Shopping / personal care', amount:5000, frequency:'monthly', protected:false, exceptional:false, dueDate:'' }
    ],
    essential: [
      { id:`rent-${month}`, name:'Rent / mortgage', amount:30000, frequency:'monthly', protected:true, exceptional:false, dueDate:'' },
      { id:`utilities-${month}`, name:'Utilities', amount:6000, frequency:'monthly', protected:true, exceptional:false, dueDate:'' },
      { id:`insurance-${month}`, name:'Insurance', amount:36000, frequency:'annual', protected:true, exceptional:false, dueDate:'' },
      { id:`transport-${month}`, name:'Transport commitment', amount:6500, frequency:'monthly', protected:false, exceptional:false, dueDate:'' }
    ],
    savings: [
      { id:`investment-${month}`, name:'Recurring investment', amount:10000, frequency:'monthly' },
      { id:`emergency-${month}`, name:'Emergency savings', amount:5000, frequency:'monthly' }
    ],
    incomes: [{ id:`income-${month}`, name:'Salary / wages', amount:120000, frequency:'monthly' }],
    summary: { income:120000, essential:45500, flexible:25000, saving:15000, reserves:3000, remaining:34500, savingsRate:12.5, coverage:180000/45500 }
  }));
  await page.evaluate(async records => {
    for (const record of records) await window.CarrowmontBudgetStorage.saveMonth(record);
  }, months);
  await page.locator('#refreshHistoryBtn').click();
  await expect(page.locator('#smartScenarioPanel')).toBeVisible();
}

test.describe('PDF report generation and download standard', () => {
  for (const tool of tools) {
    test(`[AUTO] ${tool.name}: PDF downloads and uses standardized success message`, async ({ page }, testInfo) => {
      test.skip(testInfo.project.name !== 'chrome-desktop', 'Generate PDFs once in Chrome to keep the full suite fast');
      test.setTimeout(120000);
      await gotoClean(page, tool.path);
      await dismissAnalyticsConsent(page);
      await prepareToolForQa(page, tool.key);
      if (tool.key === 'budget-cash-flow-planner') await seedBudgetSs2History(page);
      await installCanvasTextProbe(page);
      const button = page.locator(tool.reportButton);
      await expect(button).toBeVisible();
      const downloadPromise = page.waitForEvent('download', { timeout: 90000 });
      await button.click();
      const download = await downloadPromise;
      const info = await validatePdfDownload(download, tool.reportMinPages);
      savePdfArtifact(info, tool.key);
      await expect(page.locator(tool.reportStatus)).toHaveText(standardDownloadMessage, { timeout: 15000 });
      expect(info.pages).toBeGreaterThanOrEqual(tool.reportMinPages);
      const canvasText = await getCanvasText(page);

      if (tool.key === 'sip-calculator') {
        expect(canvasText).toContain('SIP Planning Report');
        expect(canvasText).toContain('Contribution frequency');
        expect(canvasText).toContain('Monthly');
      }

      if (tool.key === 'goal-planner') {
        expect(canvasText).toContain('Pay frequency');
        expect(canvasText).toContain('Savings / contribution frequency');
        expect(canvasText).toContain('Alternative one-time investment');
        expect(canvasText).toContain('Monthly');
      }

      if (tool.key === 'financial-independence') {
        expect(canvasText).toContain('Income / pay frequency');
        expect(canvasText).toContain('Investment frequency');
        expect(canvasText).toContain('Monthly');
      }

      if (tool.key === 'retirement-planner') {
        expect(canvasText).toContain('Pay frequency');
        expect(canvasText).toContain('Retirement contribution frequency');
        expect(canvasText).toContain('Monthly');
        expect(canvasText).toContain('retirement contribution required');
      }

      if (tool.key === 'mortgage-payoff-calculator') {
        const mortgageText = canvasText.replace(/\s+/g, ' ').trim();
        expect(mortgageText).toContain('Home Loan Prepayment / Foreclosure');
        expect(mortgageText).toContain('Scheduled repayment frequency');
        expect(mortgageText).toContain('Planning view');
        expect(mortgageText).toContain('Recurring part-prepayment was not enabled');
        expect(mortgageText).toContain('No country-specific cadence was assumed');
      }

      if (tool.key === 'budget-cash-flow-planner') {
        const budgetText = canvasText.replace(/\s+/g, ' ').trim();
        const webSuggestionTitles = await page.locator('#insightGrid .insight-card h3').allInnerTexts();
        const webEvidenceLabels = await page.locator('#insightGrid .smart-evidence-badge').allInnerTexts();
        expect(budgetText).toContain('Budget & Cash Flow Report');
        expect(budgetText).toContain('SMART SUGGESTIONS');
        for (const title of webSuggestionTitles.slice(0, 3)) expect(budgetText).toContain(title.replace(/\s+/g, ' ').trim());
        for (const label of webEvidenceLabels.slice(0, 3)) expect(budgetText.toUpperCase()).toContain(label.trim().toUpperCase());
        expect(budgetText).toContain('SELECTED SCENARIO');
        expect(budgetText).toContain('Scenario breakdown');
        expect(budgetText).toContain('/ 12 months');
        expect(budgetText).toContain('Monthly cash-flow summary');
        expect(budgetText.toLowerCase()).toContain('emergency reserve');
        expect(budgetText).toContain('Irregular-bill reserves');
        expect(budgetText).toContain('Saved history and comparison notes');
        expect(budgetText).toContain('HOW THIS REPORT INTERPRETS YOUR ENTRIES');
        expect(budgetText).toContain('Different frequencies');
        expect(budgetText).toContain('Irregular / monthly average');
        expect(budgetText).toContain('Quarterly & annual bills');
        expect(budgetText).toContain('Exceptional entries');
        expect(budgetText).toContain('left out of the normal comparison baseline');
      }

      if (tool.requiresGuideReportPage) {
        expect(canvasText, `${tool.name} report missing Report Guide & Methodology page`).toContain('Report Guide & Methodology');
        expect(canvasText, `${tool.name} report missing How to read section`).toContain('How to read this report');
        expect(canvasText, `${tool.name} report missing terminology section`).toContain('Terminology used in this report');
        expect(canvasText, `${tool.name} report missing disclaimer section`).toContain('Important assumptions & disclaimer');
        expect(canvasText, `${tool.name} report missing contact details`).toContain('contact@carrowmont.com');
      }

      if (tool.requiresToolsReportPage) {
        expect(canvasText).toContain('Continue planning with Carrowmont');
        const expectedOtherTools = {
          'financial-independence': ['SIP Calculator', 'Retirement Planner', 'Goal Planner', 'Inflation Calculator', 'Budget & Cash Flow Planner', 'Home Loan Prepayment'],
          'goal-planner': ['SIP Calculator', 'Retirement Planner', 'Financial Independence', 'Inflation Calculator', 'Budget & Cash Flow Planner', 'Home Loan Prepayment'],
          'inflation-calculator': ['SIP Calculator', 'Retirement Planner', 'Goal Planner', 'Financial Independence', 'Budget & Cash Flow Planner', 'Home Loan Prepayment'],
          'retirement-planner': ['SIP Calculator', 'Goal Planner', 'Financial Independence', 'Inflation Calculator', 'Budget & Cash Flow Planner', 'Home Loan Prepayment'],
          'sip-calculator': ['Retirement Planner', 'Goal Planner', 'Financial Independence', 'Inflation Calculator', 'Budget & Cash Flow Planner', 'Home Loan Prepayment'],
          'budget-cash-flow-planner': ['SIP Calculator', 'Retirement Planner', 'Goal Planner', 'Financial Independence', 'Inflation Calculator', 'Home Loan Prepayment'],
          'mortgage-payoff-calculator': ['SIP Calculator', 'Retirement Planner', 'Goal Planner', 'Financial Independence', 'Inflation Calculator', 'Budget & Cash Flow Planner']
        }[tool.key] || [];
        for (const title of expectedOtherTools) expect(canvasText, `${tool.name} report missing ${title}`).toContain(title);
      }

      if (tool.key === 'financial-independence') {
        expect(canvasText).toContain('Permanent printed callouts');
        expect(canvasText).toContain('Target ');
        expect(canvasText).toContain('Portfolio ');
      }
    });
  }

  test('[AUTO] International report tool card uses Recurring Investment Calculator instead of SIP Calculator', async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== 'chrome-desktop', 'Generate this report once in Chrome');
    test.setTimeout(120000);
    await gotoClean(page, '/goal-planner/');
    await dismissAnalyticsConsent(page);
    await chooseUnitedStatesLocale(page);
    await installCanvasTextProbe(page);
    const downloadPromise = page.waitForEvent('download', { timeout: 90000 });
    await page.locator('#reportBtn').click();
    const download = await downloadPromise;
    const info = await validatePdfDownload(download, 5);
    savePdfArtifact(info, 'goal-planner-international');
    const canvasText = await getCanvasText(page);
    expect(canvasText).toContain('Recurring Investment Calculator');
    expect(canvasText).not.toContain('Monthly Investment Calculator');
  });

  test('[AUTO] Financial Independence PDF includes printed values for both charts', async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== 'chrome-desktop', 'Generate this report once in Chrome');
    test.setTimeout(120000);
    await gotoClean(page, '/financial-independence/');
    await dismissAnalyticsConsent(page);
    await prepareToolForQa(page, 'financial-independence');
    await installCanvasTextProbe(page);
    const downloadPromise = page.waitForEvent('download', { timeout: 90000 });
    await page.locator('#reportBtn').click();
    await downloadPromise;
    const canvasText = await getCanvasText(page);
    expect(canvasText).toContain('FI Target');
    expect(canvasText).toContain('Projected Portfolio Value');
    expect(canvasText).toContain('Money Added');
    expect(canvasText).toContain('Target Age 50');
    expect(canvasText).toContain('Financial Independence Journey');
    const normalizedCanvasText = canvasText.replace(/\s+/g, ' ');
    expect(normalizedCanvasText).toContain('INVESTMENT THAT YEAR');
    expect(normalizedCanvasText).toContain('FUNDING %');
    expect(canvasText).toContain('Permanent printed callouts');
  });

  test('[AUTO] Financial Independence Plan Until Age PDF states the planning horizon and longevity outputs', async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== 'chrome-desktop', 'Generate this report once in Chrome');
    test.setTimeout(120000);
    await gotoClean(page, '/financial-independence/');
    await dismissAnalyticsConsent(page);
    await page.locator('#planningModeUntilAge').check();
    await setInput(page, '#currentAge', 40);
    await setInput(page, '#targetAge', 50);
    await setInput(page, '#planUntilAge', 60);
    await setInput(page, '#monthlySpending', 2000);
    await setInput(page, '#spendingPct', 100);
    await setInput(page, '#monthlyIncome', 500);
    await setInput(page, '#inflation', 3);
    await setInput(page, '#currentAssets', 100000);
    await setInput(page, '#monthlyContribution', 1000);
    await setInput(page, '#annualReturn', 6);
    await setInput(page, '#annualStepUp', 0);
    await installCanvasTextProbe(page);
    const downloadPromise = page.waitForEvent('download', { timeout: 90000 });
    await page.locator('#reportBtn').click();
    await downloadPromise;
    const canvasText = await getCanvasText(page);
    expect(canvasText).toContain('Planning approach');
    expect(canvasText).toContain('Plan Until Age');
    expect(canvasText).toContain('Required Portfolio');
    expect(canvasText).toContain('Projected balance at Plan Until Age');
    expect(canvasText).toContain('Portfolio longevity');
    expect(canvasText).toContain('planning horizon, not a prediction of lifespan');
    expect(canvasText).toContain('inflation-adjusted spending model');
    expect(canvasText).toContain('Inflation treatment');
    expect(canvasText).toContain('future nominal');
    expect(canvasText).toContain('Plan Longevity');
    expect(canvasText).toContain('Financial Independence Journey');
    const normalizedCanvasText = canvasText.replace(/\s+/g, ' ');
    expect(normalizedCanvasText).toContain('PORTFOLIO-FUNDED SPENDING');
    expect(normalizedCanvasText).toContain('END PORTFOLIO VALUE');
    expect(canvasText).toContain('Drawdown');
  });

});
