CARROWMONT GSEO1C TRUST + STRUCTURED DATA FOUNDATION — FIX1

Baseline: Source Snapshot 54
Release ID: gseo1c-trust-structured-data-v1-fix1

Production scope is unchanged from the original GSEO1C release.

Publisher rehearsal found four stale QA assumptions:
1. About smoke marker still expected the old phrase "SIP Calculator" after the intentional About rewrite.
2. Editorial Policy smoke marker used different capitalization from the published page.
3. TOOLS-HUB1 assumed the tools-directory JSON-LD root was directly CollectionPage; GSEO1C intentionally wraps CollectionPage + BreadcrumbList in @graph.
4. TOOLS-HUB1 hard-coded the previous tools.html sitemap lastmod (2026-10-10) even though GSEO1C changes tools.html and correctly refreshes it to 2026-10-13.

FIX1 changes only central QA expectations for those four cases. It does not alter the production GSEO1C design or calculator behavior.

Expected Publisher output: 9 PRs, merged in the approved repository order with carrowmont-qa last.
