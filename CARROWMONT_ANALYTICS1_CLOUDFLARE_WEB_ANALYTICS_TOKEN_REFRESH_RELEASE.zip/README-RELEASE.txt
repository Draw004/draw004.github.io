CARROWMONT ANALYTICS1 - CLOUDFLARE WEB ANALYTICS TOKEN REFRESH

Purpose
- Replace the retired Cloudflare Web Analytics token with the newly provisioned carrowmont.com token.
- Preserve Carrowmont's privacy-first analytics boundary: no Google Analytics, no consent popup, and no calculator inputs/results sent to analytics.
- Cache-bust main-site site.js and tool analytics.js references so the new token rolls out immediately.

Active Cloudflare token
- be7aec3cfdf3419e97d4452d4de3d672

Retired token removed
- 713a819bf0244b9fb4245554a6f20ee2

Validation
- Source contract: 708 PASS / 0 FAIL
- JavaScript syntax: PASS
- Browser QA remains delegated to Batch PR Publisher on the exact staged bundle.

Boundaries
- No DNS or nameserver changes.
- No GitHub workflow files.
- No calculator/formula changes.
- No newsletter/Kit changes.
- No Google Analytics or analytics consent UI.
