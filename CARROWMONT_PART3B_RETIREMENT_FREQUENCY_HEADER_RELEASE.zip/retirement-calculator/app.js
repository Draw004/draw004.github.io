(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const L = window.CarrowmontLocale;
  const REPORT_ENGINE = window.CarrowmontReportEngine;
  const APP_CONFIG = window.CARROWMONT_RETIREMENT_CONFIG || {};
  const qsa = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const STORAGE_KEY = 'carrowmont-retirement-plan-v1';
  const LEGACY_STORAGE_KEY = 'retirewise-v2-plan';

  const DEFAULTS = {
    mode: 'quick',
    currentAge: 35,
    retirementAge: 60,
    planningAge: 90,
    currentSavings: 1000000,
    currentMonthlyInvestment: 20000,
    preReturn: 10,
    postReturn: 7.5,
    bufferRate: 10,
    quickMonthlyExpense: 90000,
    quickRetirementPct: 65,
    quickInflation: 5,
    generalInflation: 5,
    healthInflation: 7,
    lifestyleInflation: 5,
    educationInflation: 7,
    phase1Pct: 110,
    phase2Pct: 90,
    phase3Pct: 70,
  };

  const DEFAULT_EXPENSES = [
    { name: 'Groceries & household', amount: 18000, inflationType: 'general', rule: 'adjust', setting: 100 },
    { name: 'Utilities & communication', amount: 6000, inflationType: 'general', rule: 'adjust', setting: 90 },
    { name: 'Home loan / rent', amount: 20000, inflationType: 'general', rule: 'end', setting: 55 },
    { name: 'School / tuition', amount: 18000, inflationType: 'education', rule: 'end', setting: 50 },
    { name: 'Transport / commuting', amount: 8000, inflationType: 'general', rule: 'adjust', setting: 50 },
    { name: 'Travel & leisure', amount: 7000, inflationType: 'lifestyle', rule: 'adjust', setting: 100 },
    { name: 'Healthcare', amount: 5000, inflationType: 'health', rule: 'adjust', setting: 160 },
    { name: 'Domestic help', amount: 3000, inflationType: 'general', rule: 'adjust', setting: 150 },
    { name: 'Other essentials', amount: 5000, inflationType: 'general', rule: 'adjust', setting: 100 },
  ];

  const DEFAULT_INCOMES = [
    { name: 'Pension / annuity', amount: 0, startAge: 60, growth: 0 },
    { name: 'Rental income', amount: 0, startAge: 60, growth: 3 },
  ];

  const DEFAULT_GOALS = [];
  let mode = DEFAULTS.mode;
  let lastResult = null;
  let suppressCalculate = false;
  let activeLocaleRegion = L ? L.getRegion() : 'IN';
  let payFrequencyUserOverride = false;
  let contributionFrequencyUserOverride = false;

  function num(value, fallback = 0) {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
  }

  function value(id, fallback = 0) {
    return num($(id)?.value, fallback);
  }

  function clamp(v, min, max) { return Math.min(max, Math.max(min, v)); }

  function formatINR(value, compact = false) {
    const n = Number(value);
    const safe = Number.isFinite(n) ? n : 0;
    if (L) {
      return compact
        ? L.formatCompactMoney(safe, { maximumFractionDigits: 2 })
        : L.formatMoney(safe, { maximumFractionDigits: 0 });
    }
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(safe);
  }

  function currencyCode() { return L ? L.getCurrency() : 'INR'; }
  function regionLabel() { return L ? L.getProfile().label : 'India'; }
  function zeroMoney(compact = false) { return formatINR(0, compact); }

  function formatAgeYearsMonths(age, includePrefix = false) {
    if (!Number.isFinite(age)) return includePrefix ? 'age —' : '—';
    const totalMonths = Math.max(0, Math.round(age * 12));
    const years = Math.floor(totalMonths / 12);
    const months = totalMonths % 12;
    const text = months ? `${years} years ${months} ${months === 1 ? 'month' : 'months'}` : `${years} years`;
    return includePrefix ? `age ${text}` : text;
  }

  function formatAgeCompact(age) {
    if (!Number.isFinite(age)) return '—';
    const totalMonths = Math.max(0, Math.round(age * 12));
    const years = Math.floor(totalMonths / 12);
    const months = totalMonths % 12;
    return months ? `${years}y ${months}m` : `${years}`;
  }

  function syncLocaleLabels() {
    const currency = currencyCode();
    const set = (id, text) => { const el = $(id); if (el) el.textContent = text; };
    set('expenseAmountHead', `Today / mo (${currency})`);
    set('incomeAmountHead', `Monthly amount when it starts (${currency})`);
    set('goalAmountHead', `Today's amount (${currency})`);
    set('firstYearExpenseLabel', `Average monthly expenses in first retirement year (future ${currency})`);
    set('retirementLifestyleTodayLabel', `Retirement lifestyle in today's money`);
    set('reportRetirementSpendLabel', `Retirement lifestyle in today's money`);
    set('glanceFutureSpendNote', `Inflation-adjusted future ${currency} estimate`);
    if (window.CarrowmontLocaleUI?.sync) window.CarrowmontLocaleUI.sync();
  }

  function applyFirstLoadMoneyDefaults() {
    // India retains the original illustrative sample. For other regions, start money
    // inputs at zero rather than presenting India-sized sample amounts as dollars,
    // pounds, yen or another currency. Rates remain editable illustrative assumptions.
    if (!L || L.getRegion() === 'IN') return;
    ['currentSavings','currentMonthlyInvestment','quickMonthlyExpense'].forEach(id => { if ($(id)) $(id).value = '0'; });
    qsa('.exp-amount', $('expenseRows')).forEach(el => { el.value = '0'; });
  }

  function effectiveMonthlyRate(annualPct) {
    return Math.pow(1 + annualPct / 100, 1 / 12) - 1;
  }

  const FREQUENCY_PERIODS = { weekly: 52, biweekly: 26, semimonthly: 24, fourweekly: 13, monthly: 12 };
  const FREQUENCY_ORDER = ['weekly','biweekly','semimonthly','fourweekly','monthly'];
  const FREQUENCY_BASE_LABELS = { weekly: 'Weekly', semimonthly: 'Twice Monthly', fourweekly: 'Every 4 Weeks', monthly: 'Monthly' };
  function frequencyProfile(regionCode = L?.getRegion?.() || 'OTHER') { return L?.regions?.[regionCode] || L?.regions?.OTHER || {}; }
  function frequencyLabel(key, regionCode = L?.getRegion?.() || 'OTHER') {
    if (key === 'biweekly') {
      const style = frequencyProfile(regionCode).twoWeekLabel || 'neutral';
      if (style === 'fortnightly') return 'Fortnightly (Every 2 Weeks)';
      if (style === 'biweekly') return 'Biweekly (Every 2 Weeks)';
      return 'Every 2 Weeks';
    }
    return FREQUENCY_BASE_LABELS[key] || 'Monthly';
  }
  function defaultFrequencyForRegion(code = L?.getRegion?.() || 'OTHER') { return frequencyProfile(code).contributionFrequency || 'monthly'; }
  function cadenceText(key) { if (key === 'weekly') return 'per week'; if (key === 'biweekly') return 'every 2 weeks'; if (key === 'semimonthly') return 'twice monthly'; if (key === 'fourweekly') return 'every 4 weeks'; return 'per month'; }
  function frequencyName(key) { return frequencyLabel(key).replace(/\s*\(Every 2 Weeks\)\s*/, '').trim(); }
  function currentContributionLabelText(key) { if (key === 'biweekly' && frequencyName(key) === 'Every 2 Weeks') return 'Current retirement contribution every 2 weeks'; if (key === 'fourweekly') return 'Current retirement contribution every 4 weeks'; return `Current ${frequencyName(key).toLowerCase()} retirement contribution`; }
  function requiredContributionLabelText(key, prefix = 'Total') { if (key === 'biweekly' && frequencyName(key) === 'Every 2 Weeks') return `${prefix} retirement contribution required every 2 weeks`; if (key === 'fourweekly') return `${prefix} retirement contribution required every 4 weeks`; return `${prefix} ${frequencyName(key).toLowerCase()} retirement contribution required`; }
  function contributionText(amount, key) { return `${formatINR(amount)} ${cadenceText(key)}`; }
  function populateFrequencySelect(select, desired) { if (!select) return; select.innerHTML = FREQUENCY_ORDER.map(key => `<option value="${key}">${frequencyLabel(key)}</option>`).join(''); select.value = FREQUENCY_ORDER.includes(desired) ? desired : 'monthly'; }
  function updateFrequencyCopy() {
    const key = $('contributionFrequency')?.value || 'monthly';
    if ($('currentContributionLabel')) $('currentContributionLabel').textContent = currentContributionLabelText(key);
    if ($('currentContributionHelp')) $('currentContributionHelp').textContent = `Enter how much you currently contribute ${cadenceText(key)} toward retirement.`;
    if ($('totalContributionNeededLabel')) $('totalContributionNeededLabel').textContent = requiredContributionLabelText(key, 'Total') + ' from today';
    if ($('extraContributionNeededLabel')) $('extraContributionNeededLabel').textContent = requiredContributionLabelText(key, 'Additional') + ' vs current plan';
  }
  function syncFrequencyOptions() {
    const suggested = defaultFrequencyForRegion();
    const pay = $('payFrequency'), contribution = $('contributionFrequency'), same = $('sameAsPayCycle');
    const payDesired = payFrequencyUserOverride ? (pay?.value || suggested) : suggested;
    populateFrequencySelect(pay, payDesired);
    const contributionDesired = same?.checked ? pay.value : (contributionFrequencyUserOverride ? (contribution?.value || suggested) : suggested);
    populateFrequencySelect(contribution, contributionDesired);
    if (same?.checked) contribution.value = pay.value;
    if (contribution) contribution.disabled = Boolean(same?.checked);
    updateFrequencyCopy();
  }
  function contributionSchedule(annualPct, years, frequency) {
    const ppy = FREQUENCY_PERIODS[frequency] || FREQUENCY_PERIODS.monthly;
    const periods = Math.max(0, Math.round(Math.max(0, years) * ppy));
    const rate = Math.pow(1 + annualPct / 100, 1 / ppy) - 1;
    const factor = periods <= 0 ? 0 : (Math.abs(rate) > 1e-12 ? (Math.pow(1 + rate, periods) - 1) / rate : periods);
    return { ppy, periods, rate, factor };
  }

  function inflationOptions(selected) {
    return [
      ['general', 'General'], ['health', 'Healthcare'], ['lifestyle', 'Lifestyle'], ['education', 'Education']
    ].map(([v,l]) => `<option value="${v}" ${v === selected ? 'selected' : ''}>${l}</option>`).join('');
  }

  function expenseRuleOptions(selected) {
    return [
      ['adjust', 'Continue / adjust'], ['end', 'Ends at age'], ['start', 'Starts at retirement']
    ].map(([v,l]) => `<option value="${v}" ${v === selected ? 'selected' : ''}>${l}</option>`).join('');
  }

  function addExpenseRow(data = {}) {
    const tr = document.createElement('tr');
    tr.className = 'expense-row';
    const d = { name: 'New expense', amount: 0, inflationType: 'general', rule: 'adjust', setting: 100, ...data };
    tr.innerHTML = `
      <td><input class="table-input name exp-name" value="${escapeAttr(d.name)}" aria-label="Expense name"></td>
      <td><input class="table-input amount exp-amount" type="number" min="0" step="1" inputmode="decimal" value="${num(d.amount)}" aria-label="Monthly amount"></td>
      <td><select class="table-select exp-inflation" aria-label="Inflation type">${inflationOptions(d.inflationType)}</select></td>
      <td><select class="table-select exp-rule" aria-label="Retirement rule">${expenseRuleOptions(d.rule)}</select></td>
      <td class="table-setting-cell"></td>
      <td><button class="remove-row" type="button" aria-label="Remove expense">×</button></td>`;
    $('expenseRows').appendChild(tr);
    renderExpenseSetting(tr, d.setting);
  }

  function renderExpenseSetting(tr, settingValue) {
    const rule = tr.querySelector('.exp-rule').value;
    const cell = tr.querySelector('.table-setting-cell');
    if (rule === 'end') {
      cell.innerHTML = `<div class="number-wrap suffix table-setting"><input class="exp-setting" type="number" min="18" max="110" value="${num(settingValue, 55)}" aria-label="Expense ends at age"><span>age</span></div>`;
    } else {
      const defaultPct = rule === 'start' ? 100 : 100;
      cell.innerHTML = `<div class="number-wrap suffix table-setting"><input class="exp-setting" type="number" min="0" max="500" value="${num(settingValue, defaultPct)}" aria-label="Percent at retirement"><span>%</span></div>`;
    }
  }

  function addIncomeRow(data = {}) {
    const d = { name: 'Other income', amount: 0, startAge: value('retirementAge', 60), growth: 0, ...data };
    const tr = document.createElement('tr');
    tr.className = 'income-row';
    tr.innerHTML = `
      <td><input class="table-input name inc-name" value="${escapeAttr(d.name)}" aria-label="Income source"></td>
      <td><input class="table-input amount inc-amount" type="number" min="0" step="1" inputmode="decimal" value="${num(d.amount)}" aria-label="Monthly income"></td>
      <td><input class="table-input inc-start" type="number" min="18" max="110" value="${num(d.startAge, 60)}" aria-label="Income start age"></td>
      <td><div class="number-wrap suffix table-setting"><input class="inc-growth" type="number" min="-10" max="20" step="0.1" value="${num(d.growth)}" aria-label="Annual income increase"><span>%</span></div></td>
      <td><button class="remove-row" type="button" aria-label="Remove income">×</button></td>`;
    $('incomeRows').appendChild(tr);
  }

  function addGoalRow(data = {}) {
    const d = { name: 'Future goal', amount: 0, age: value('retirementAge', 60) + 5, inflationType: 'general', ...data };
    const tr = document.createElement('tr');
    tr.className = 'goal-row';
    tr.innerHTML = `
      <td><input class="table-input name goal-name" value="${escapeAttr(d.name)}" aria-label="Goal name"></td>
      <td><input class="table-input amount goal-amount" type="number" min="0" step="1" inputmode="decimal" value="${num(d.amount)}" aria-label="Goal amount"></td>
      <td><input class="table-input goal-age" type="number" min="18" max="110" value="${num(d.age)}" aria-label="Goal age"></td>
      <td><select class="table-select goal-inflation" aria-label="Goal inflation">${inflationOptions(d.inflationType)}</select></td>
      <td><button class="remove-row" type="button" aria-label="Remove goal">×</button></td>`;
    $('goalRows').appendChild(tr);
  }

  function escapeAttr(s) {
    return String(s ?? '').replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function readExpenses() {
    return qsa('.expense-row', $('expenseRows')).map(tr => ({
      name: tr.querySelector('.exp-name').value.trim() || 'Expense',
      amount: num(tr.querySelector('.exp-amount').value),
      inflationType: tr.querySelector('.exp-inflation').value,
      rule: tr.querySelector('.exp-rule').value,
      setting: num(tr.querySelector('.exp-setting')?.value, 100),
    }));
  }

  function readIncomes() {
    return qsa('.income-row', $('incomeRows')).map(tr => ({
      name: tr.querySelector('.inc-name').value.trim() || 'Income',
      amount: num(tr.querySelector('.inc-amount').value),
      startAge: num(tr.querySelector('.inc-start').value),
      growth: num(tr.querySelector('.inc-growth').value),
    }));
  }

  function readGoals() {
    return qsa('.goal-row', $('goalRows')).map(tr => ({
      name: tr.querySelector('.goal-name').value.trim() || 'Goal',
      amount: num(tr.querySelector('.goal-amount').value),
      age: num(tr.querySelector('.goal-age').value),
      inflationType: tr.querySelector('.goal-inflation').value,
    }));
  }

  function buildState(overrides = {}) {
    const s = {
      mode,
      currentAge: value('currentAge'), retirementAge: value('retirementAge'), planningAge: value('planningAge'),
      currentSavings: value('currentSavings'), currentMonthlyInvestment: value('currentMonthlyInvestment'),
      payFrequency: $('payFrequency')?.value || 'monthly', contributionFrequency: $('contributionFrequency')?.value || 'monthly', sameAsPayCycle: Boolean($('sameAsPayCycle')?.checked),
      preReturn: value('preReturn'), postReturn: value('postReturn'), bufferRate: value('bufferRate'),
      quickMonthlyExpense: value('quickMonthlyExpense'), quickRetirementPct: value('quickRetirementPct'), quickInflation: value('quickInflation'),
      generalInflation: value('generalInflation'), healthInflation: value('healthInflation'), lifestyleInflation: value('lifestyleInflation'), educationInflation: value('educationInflation'),
      phase1Pct: value('phase1Pct'), phase2Pct: value('phase2Pct'), phase3Pct: value('phase3Pct'),
      expenses: readExpenses(), incomes: readIncomes(), goals: readGoals(),
    };
    return { ...s, ...overrides };
  }

  function inflationPct(type, s) {
    if (s.mode === 'quick') return s.quickInflation;
    if (type === 'health') return s.healthInflation;
    if (type === 'lifestyle') return s.lifestyleInflation;
    if (type === 'education') return s.educationInflation;
    return s.generalInflation;
  }

  function lifestylePhaseMultiplier(age, s) {
    if (age < s.retirementAge) return 1;
    const y = age - s.retirementAge;
    if (y < 10) return s.phase1Pct / 100;
    if (y < 20) return s.phase2Pct / 100;
    return s.phase3Pct / 100;
  }

  function detailedExpenseAtAge(exp, age, s, nominal = true) {
    if (exp.amount <= 0) return 0;
    let factor = 1;
    if (age < s.retirementAge) {
      if (exp.rule === 'start') return 0;
      if (exp.rule === 'end' && age >= exp.setting) return 0;
    } else {
      if (exp.rule === 'end') {
        if (age >= exp.setting) return 0;
      } else {
        factor = exp.setting / 100;
      }
      if (exp.inflationType === 'lifestyle') factor *= lifestylePhaseMultiplier(age, s);
    }
    const inflation = inflationPct(exp.inflationType, s) / 100;
    const years = Math.max(0, age - s.currentAge);
    const inflationFactor = nominal ? Math.pow(1 + inflation, years) : 1;
    return exp.amount * factor * inflationFactor;
  }

  function expenseAtAge(age, s, nominal = true) {
    if (s.mode === 'quick') {
      const inflation = s.quickInflation / 100;
      const inflated = s.quickMonthlyExpense * (nominal ? Math.pow(1 + inflation, Math.max(0, age - s.currentAge)) : 1);
      return age < s.retirementAge ? inflated : inflated * s.quickRetirementPct / 100;
    }
    return s.expenses.reduce((sum, exp) => sum + detailedExpenseAtAge(exp, age, s, nominal), 0);
  }

  function incomeAtAge(age, s) {
    if (s.mode === 'quick') return 0;
    return s.incomes.reduce((sum, inc) => {
      if (inc.amount <= 0 || age + 1e-9 < inc.startAge) return sum;
      const years = Math.max(0, age - inc.startAge);
      return sum + inc.amount * Math.pow(1 + inc.growth / 100, years);
    }, 0);
  }

  function goalFutureAmount(goal, s) {
    const inflation = inflationPct(goal.inflationType, s) / 100;
    return goal.amount * Math.pow(1 + inflation, Math.max(0, goal.age - s.currentAge));
  }

  function validateState(s) {
    const errors = [];
    if (s.currentAge < 18) errors.push('Current age must be at least 18.');
    if (s.retirementAge <= s.currentAge) errors.push('Retirement age must be greater than current age.');
    if (s.planningAge <= s.retirementAge) errors.push('Plan-until age must be greater than retirement age.');
    if (s.planningAge > 110) errors.push('Plan-until age cannot exceed 110 in this calculator.');
    if (s.preReturn < 0 || s.postReturn < 0 || s.bufferRate < 0) errors.push('Return and buffer assumptions cannot be negative.');
    if (s.mode === 'quick' && s.quickMonthlyExpense <= 0) errors.push('Enter a positive monthly household expense.');
    if (s.mode === 'detailed' && s.expenses.every(e => e.amount <= 0)) errors.push('Add at least one expense with a positive amount.');
    return errors;
  }

  function calculatePlan(s) {
    const errors = validateState(s);
    if (errors.length) return { errors };

    const monthsToRetire = Math.round((s.retirementAge - s.currentAge) * 12);
    const retirementMonths = Math.round((s.planningAge - s.retirementAge) * 12);
    const monthlyPost = effectiveMonthlyRate(s.postReturn);

    const goalByMonth = new Map();
    if (s.mode === 'detailed') {
      for (const goal of s.goals) {
        if (goal.amount <= 0 || goal.age < s.retirementAge || goal.age > s.planningAge) continue;
        const m = clamp(Math.round((goal.age - s.retirementAge) * 12), 0, Math.max(0, retirementMonths - 1));
        goalByMonth.set(m, (goalByMonth.get(m) || 0) + goalFutureAmount(goal, s));
      }
    }

    let recurringExpensePV = 0;
    let retirementIncomePV = 0;
    let goalsPV = 0;
    let firstYearExpenseTotal = 0;
    let firstYearIncomeTotal = 0;
    const monthlyFlows = [];

    for (let m = 0; m < retirementMonths; m++) {
      const age = s.retirementAge + m / 12;
      const expense = expenseAtAge(age, s, true);
      const income = incomeAtAge(age, s);
      const goal = goalByMonth.get(m) || 0;
      const net = expense - income;
      const discount = Math.pow(1 + monthlyPost, m);
      recurringExpensePV += expense / discount;
      retirementIncomePV += income / discount;
      goalsPV += goal / discount;
      monthlyFlows.push({ m, age, expense, income, net, goal });
      if (m < 12) { firstYearExpenseTotal += expense; firstYearIncomeTotal += income; }
    }

    const baseCorpusPV = Math.max(0, recurringExpensePV - retirementIncomePV + goalsPV);
    const safetyBufferAmount = baseCorpusPV * s.bufferRate / 100;
    const requiredCorpus = baseCorpusPV + safetyBufferAmount;

    const futureExisting = s.currentSavings * Math.pow(1 + s.preReturn / 100, s.retirementAge - s.currentAge);
    const recurring = contributionSchedule(s.preReturn, s.retirementAge - s.currentAge, s.contributionFrequency);
    const fvFactor = recurring.factor;
    const futureCurrentContrib = s.currentMonthlyInvestment * Math.max(0, fvFactor);
    const projectedCorpus = futureExisting + futureCurrentContrib;
    const gap = Math.max(0, requiredCorpus - projectedCorpus);

    const gapBeforeContrib = Math.max(0, requiredCorpus - futureExisting);
    const totalMonthlyNeeded = recurring.periods > 0 && fvFactor > 0 ? gapBeforeContrib / fvFactor : 0;
    const extraMonthlyNeeded = Math.max(0, totalMonthlyNeeded - s.currentMonthlyInvestment);
    const fundedPct = requiredCorpus > 0 ? (projectedCorpus / requiredCorpus) * 100 : 100;

    const firstYearExpense = firstYearExpenseTotal / Math.max(1, Math.min(12, retirementMonths));
    const firstYearIncome = firstYearIncomeTotal / Math.max(1, Math.min(12, retirementMonths));
    const firstYearNet = Math.max(0, firstYearExpense - firstYearIncome);

    const currentTodayExpense = expenseAtAge(s.currentAge, s, false);
    const retirementLifestyleToday = expenseAtAge(s.retirementAge, s, false);
    // Same retirement lifestyle expressed in nominal future money at the selected retirement age.
    const retirementLifestyleFuture = expenseAtAge(s.retirementAge, s, true);

    // Keep every entered expense with a positive amount, in the same order as the planner.
    // This makes the retirement breakdown a complete audit trail rather than a filtered "changes only" list.
    const expenseChanges = s.mode === 'detailed' ? s.expenses.map(exp => {
      const today = detailedExpenseAtAge(exp, s.currentAge, s, false);
      const retirement = detailedExpenseAtAge(exp, s.retirementAge, s, false);
      const retirementFuture = detailedExpenseAtAge(exp, s.retirementAge, s, true);
      return {
        name: exp.name, amount: exp.amount, today, retirement, retirementFuture,
        change: retirement - today, rule: exp.rule, setting: exp.setting, inflationType: exp.inflationType
      };
    }).filter(x => x.amount > 0) : [];
    const monthlyReduced = s.mode === 'quick'
      ? Math.max(0, currentTodayExpense - retirementLifestyleToday)
      : expenseChanges.reduce((sum, x) => sum + Math.max(0, x.today - x.retirement), 0);
    const monthlyIncreased = s.mode === 'quick'
      ? Math.max(0, retirementLifestyleToday - currentTodayExpense)
      : expenseChanges.reduce((sum, x) => sum + Math.max(0, x.retirement - x.today), 0);

    // Simulate both the modelled target-funded portfolio and the user's projected current-plan portfolio.
    // The second path makes the chart decision-useful: it shows whether the current savings plan may run out
    // before the selected planning age under the same constant assumptions.
    function simulatePortfolio(startBalance) {
      let balance = Math.max(0, startBalance);
      let depletionAge = null;
      const points = [{ age: s.retirementAge, value: balance }];
      for (const flow of monthlyFlows) {
        const beforeReturn = balance - flow.net - flow.goal;
        if (depletionAge === null && beforeReturn <= 0 && (flow.net + flow.goal) > 0) {
          depletionAge = flow.age;
          // Preserve the exact modelled depletion month on the chart instead of only
          // keeping annual points. This lets the red marker and tooltip agree.
          points.push({ age: depletionAge, value: 0, depletionPoint: true });
        }
        balance = Math.max(0, beforeReturn);
        if (balance > 0) balance *= (1 + monthlyPost);
        if ((flow.m + 1) % 12 === 0 || flow.m === monthlyFlows.length - 1) {
          const pointAge = Math.min(s.planningAge, s.retirementAge + (flow.m + 1) / 12);
          if (!points.some(p => Math.abs(p.age - pointAge) < 1e-9)) points.push({ age: pointAge, value: balance });
        }
      }
      points.sort((a,b) => a.age - b.age);
      return { points, depletionAge };
    }

    const targetPortfolio = simulatePortfolio(requiredCorpus);
    const currentPlanPortfolio = simulatePortfolio(projectedCorpus);
    const portfolioPoints = targetPortfolio.points;
    const currentPortfolioPoints = currentPlanPortfolio.points;
    const projectedDepletionAge = currentPlanPortfolio.depletionAge;

    const expensePoints = [];
    const spanYears = s.planningAge - s.currentAge;
    const step = spanYears > 55 ? 2 : 1;
    for (let age = s.currentAge; age <= s.planningAge + 1e-9; age += step) {
      expensePoints.push({ age, value: expenseAtAge(age, s, true) });
    }
    if (!expensePoints.some(p => Math.abs(p.age - s.retirementAge) < .001)) expensePoints.push({ age: s.retirementAge, value: expenseAtAge(s.retirementAge, s, true) });
    expensePoints.sort((a,b) => a.age - b.age);

    return {
      errors: [], s, requiredCorpus, baseCorpusPV, recurringExpensePV, retirementIncomePV, goalsPV, safetyBufferAmount,
      futureExisting, futureCurrentContrib, projectedCorpus, gap, totalMonthlyNeeded, extraMonthlyNeeded, fundedPct,
      contributionPeriods: recurring.periods, contributionPeriodsPerYear: recurring.ppy,
      firstYearExpense, firstYearIncome, firstYearNet, currentTodayExpense, retirementLifestyleToday, retirementLifestyleFuture, monthlyReduced, monthlyIncreased,
      expenseChanges, portfolioPoints, currentPortfolioPoints, projectedDepletionAge, expensePoints, monthlyFlows,
    };
  }

  function setMode(newMode, recalc = true) {
    mode = newMode === 'detailed' ? 'detailed' : 'quick';
    $('quickPanel').classList.toggle('hidden', mode !== 'quick');
    $('detailedPanel').classList.toggle('hidden', mode !== 'detailed');
    $('quickModeBtn').classList.toggle('active', mode === 'quick');
    $('detailedModeBtn').classList.toggle('active', mode === 'detailed');
    $('modeHelp').textContent = mode === 'quick'
      ? "Fast estimate: one retirement-spending percentage and one inflation rate are applied to your household total."
      : 'Detailed planning: each expense can use its own inflation category, retirement rule and lifestyle phase, so the corpus may differ from Quick estimate.';
    if (recalc) calculateAndRender();
  }

  function calculateAndRender() {
    if (suppressCalculate) return;
    const s = buildState();
    const result = calculatePlan(s);
    const msg = $('validationMsg');
    const emptyMoneyStart = Boolean(s.currentSavings <= 0 && s.currentMonthlyInvestment <= 0 && ((s.mode === 'quick' && s.quickMonthlyExpense <= 0) || (s.mode === 'detailed' && s.expenses.every(e => e.amount <= 0))));
    if (result.errors?.length) {
      msg.classList.toggle('start-hint', emptyMoneyStart);
      msg.textContent = emptyMoneyStart
        ? `Enter your monetary amounts in ${currencyCode()} to begin. The rates shown are editable assumptions, not country-specific forecasts.`
        : result.errors.join(' ');
      if (emptyMoneyStart) setEmptyResultState('Enter monetary amounts to calculate your retirement plan.');
      return;
    }
    msg.classList.remove('start-hint');
    msg.textContent = '';
    lastResult = result;
    renderResult(result);
  }

  function fundingStatusText(fundedPct) {
    const pct = Math.max(0, fundedPct);
    const rounded = pct.toFixed(0);
    if (pct >= 110) return ['Above target under assumptions', `Under these assumptions, your projected retirement assets are about ${rounded}% of the modelled target.`];
    if (pct >= 100) return ['Target funded under assumptions', `Under these assumptions, your projected retirement assets cover about ${rounded}% of the modelled target.`];
    if (pct >= 75) return ['Most of the target is funded', `Under these assumptions, your projected retirement assets cover about ${rounded}% of the modelled target.`];
    if (pct >= 50) return ['Partly funded', `Under these assumptions, your projected retirement assets cover about ${rounded}% of the modelled target.`];
    return ['Funding gap to address', `Under these assumptions, your projected retirement assets cover about ${rounded}% of the modelled target.`];
  }

  function expenseRuleSummary(exp, s) {
    const retirementAge = Math.round(s.retirementAge);
    const setting = num(exp.setting, 100);
    let summary;

    if (exp.rule === 'end') {
      const endAge = Math.round(setting);
      summary = endAge <= retirementAge
        ? `Ends at age ${endAge} · not included at retirement`
        : `Continues at retirement · ends at age ${endAge}`;
    } else if (exp.rule === 'start') {
      summary = `Starts at retirement at ${setting.toFixed(0)}% of today's amount`;
    } else if (Math.abs(setting - 100) < 0.5) {
      summary = `Continues at 100% of today's amount`;
    } else if (setting < 100) {
      summary = `Reduced to ${setting.toFixed(0)}% at retirement`;
    } else {
      summary = `Increases to ${setting.toFixed(0)}% at retirement`;
    }

    if (exp.inflationType === 'lifestyle' && !(exp.rule === 'end' && setting <= retirementAge)) {
      summary += ` · lifestyle phase ${s.phase1Pct.toFixed(0)}% in the first 10 years`;
    }
    return summary;
  }

  function renderExpenseChanges(r) {
    const list = $('expenseChangeList');
    const retirementAge = Math.round(r.s.retirementAge);
    const headingAge = $('expenseChangeRetirementAge');
    if (headingAge) headingAge.textContent = `all listed expenses · retirement age ${retirementAge} · future ${currencyCode()}`;

    if (r.s.mode !== 'detailed') {
      const pct = r.currentTodayExpense > 0 ? (r.retirementLifestyleToday / r.currentTodayExpense) * 100 : 0;
      list.innerHTML = `<div class="change-summary-only">
        <strong>${pct.toFixed(0)}%</strong>
        <span>of today's spending is set to remain at retirement in Quick mode.</span>
        <div class="change-quick-values">
          <div><span>Retirement lifestyle<br>in today's money</span><b>${formatINR(r.retirementLifestyleToday, true)}/mo</b></div>
          <div><span>Projected at retirement (age ${retirementAge})<br>in future ${currencyCode()}</span><b>${formatINR(r.retirementLifestyleFuture, true)}/mo</b></div>
        </div>
        <small>Quick mode uses one spending percentage and one inflation rate. Switch to Detailed planner for the full expense-by-expense breakdown.</small>
      </div>`;
      return;
    }

    if (!r.expenseChanges.length) {
      list.innerHTML = '<div class="change-summary-only"><strong>No expenses entered</strong><span>Add an expense with a positive monthly amount to build the detailed retirement breakdown.</span></div>';
      return;
    }

    list.innerHTML = r.expenseChanges.map(x => {
      const cls = x.change > 0 ? 'up' : x.change < 0 ? 'down' : '';
      const label = Math.abs(x.change) < 1 ? 'No lifestyle change' : x.change > 0 ? `+${formatINR(x.change)}` : `−${formatINR(Math.abs(x.change))}`;
      const ruleSummary = expenseRuleSummary(x, r.s);
      return `<div class="expense-change-row">
        <div class="expense-change-context">
          <strong>${escapeXml(x.name)}</strong>
          <span>Current today: ${formatINR(x.today)}/mo <em class="${cls}">${label}</em></span>
          <small class="expense-change-rule">${escapeXml(ruleSummary)}</small>
        </div>
        <div class="expense-change-values">
          <div><span>Retirement lifestyle<br>in today's money</span><b>${formatINR(x.retirement)}/mo</b></div>
          <div><span>Projected at retirement (age ${retirementAge})<br>in future ${currencyCode()}</span><b>${formatINR(x.retirementFuture)}/mo</b></div>
        </div>
      </div>`;
    }).join('');
  }

  function renderPlanInsights(r) {
    const s = r.s;
    const lifestyleEl = $('insightLifestyle');
    const lifestyleNote = $('insightLifestyleNote');
    const runwayEl = $('insightRunway');
    const runwayNote = $('insightRunwayNote');
    const contributionEl = $('insightContribution');
    const contributionNote = $('insightContributionNote');
    const expenseEl = $('insightExpense');
    const expenseNote = $('insightExpenseNote');
    if (!lifestyleEl || !runwayEl || !contributionEl || !expenseEl) return;

    const lifestylePct = r.currentTodayExpense > 0 ? ((r.retirementLifestyleToday / r.currentTodayExpense) - 1) * 100 : 0;
    if (Math.abs(lifestylePct) < 1) lifestyleEl.textContent = 'About the same';
    else lifestyleEl.textContent = `${Math.abs(lifestylePct).toFixed(0)}% ${lifestylePct < 0 ? 'lower' : 'higher'}`;
    lifestyleNote.textContent = `${formatINR(r.currentTodayExpense)}/mo today → ${formatINR(r.retirementLifestyleToday)}/mo at retirement in today's purchasing power.`;

    if (r.projectedDepletionAge !== null && r.projectedDepletionAge < s.planningAge - 0.05) {
      runwayEl.textContent = `Around ${formatAgeYearsMonths(Math.max(s.retirementAge, r.projectedDepletionAge), true)}`;
      runwayNote.textContent = 'Illustrative month at which the portfolio from your current savings plan may reach zero under the entered assumptions.';
    } else {
      runwayEl.textContent = `Through age ${Math.round(s.planningAge)}`;
      runwayNote.textContent = 'The projected current-plan portfolio does not reach zero before the selected plan-through age under these assumptions.';
    }

    if (r.extraMonthlyNeeded > 1) {
      contributionEl.textContent = `+${contributionText(r.extraMonthlyNeeded, s.contributionFrequency)}`;
      contributionNote.textContent = `On top of your current retirement contribution of ${contributionText(s.currentMonthlyInvestment, s.contributionFrequency)}, under these assumptions.`;
    } else {
      contributionEl.textContent = 'No increase indicated';
      contributionNote.textContent = `Your current retirement contribution of ${contributionText(s.currentMonthlyInvestment, s.contributionFrequency)} is sufficient for the modelled target under these assumptions.`;
    }

    if (s.mode === 'detailed' && r.expenseChanges.length) {
      const biggest = r.expenseChanges.reduce((best, x) => Math.abs(x.change) > Math.abs(best.change) ? x : best, r.expenseChanges[0]);
      const sign = biggest.change > 0 ? '+' : biggest.change < 0 ? '−' : '';
      expenseEl.textContent = Math.abs(biggest.change) < 1 ? 'No major change' : `${biggest.name}: ${sign}${formatINR(Math.abs(biggest.change))}/mo`;
      expenseNote.textContent = expenseRuleSummary(biggest, s);
    } else {
      expenseEl.textContent = `${s.quickRetirementPct.toFixed(0)}% retained`;
      expenseNote.textContent = 'Quick Estimate applies one retirement-spending percentage to the household total.';
    }
  }

  function renderResult(r) {
    const s = r.s;
    if ($('copyBtn')) $('copyBtn').disabled = false;
    if ($('printBtn')) $('printBtn').disabled = false;
    $('yearsToRetire').textContent = (s.retirementAge - s.currentAge).toFixed(0);
    $('resultPlanningAge').textContent = s.planningAge.toFixed(0);
    $('requiredCorpus').textContent = formatINR(r.requiredCorpus, true);
    $('firstYearExpense').textContent = formatINR(r.firstYearExpense, true);
    const futureSpendLabel = $('futureSpendLabel');
    if (futureSpendLabel) futureSpendLabel.textContent = `Projected monthly spending at retirement (age ${Math.round(s.retirementAge)}, future ${currencyCode()})`;
    const retirementProjectedSpend = $('retirementProjectedSpend');
    if (retirementProjectedSpend) retirementProjectedSpend.textContent = `${formatINR(r.retirementLifestyleFuture, true)}/mo`;
    $('firstYearIncome').textContent = r.firstYearIncome > 0 ? formatINR(r.firstYearIncome, true) : 'None entered';
    $('firstYearNet').textContent = `${formatINR(r.firstYearNet, true)}/mo`;
    $('projectedCorpus').textContent = formatINR(r.projectedCorpus, true);
    $('corpusGap').textContent = r.gap > 0 ? formatINR(r.gap, true) : 'No gap*';
    $('totalMonthlyNeeded').textContent = contributionText(r.totalMonthlyNeeded, s.contributionFrequency);
    $('extraMonthlyNeeded').textContent = r.extraMonthlyNeeded > 1 ? contributionText(r.extraMonthlyNeeded, s.contributionFrequency) : `${zeroMoney()} under assumptions`;

    const fundedDisplay = Math.min(999, Math.max(0, r.fundedPct));
    $('fundedPercent').textContent = `${fundedDisplay.toFixed(0)}%`;
    $('progressFill').style.width = `${Math.min(100, fundedDisplay)}%`;
    $('fundingMessage').textContent = r.fundedPct >= 100
      ? `Your entered savings and current retirement contribution of ${contributionText(s.currentMonthlyInvestment, s.contributionFrequency)} meet or exceed the modelled target under these assumptions.`
      : `The current plan is projected to fund about ${Math.max(0, r.fundedPct).toFixed(0)}% of the modelled target.`;

    const [status, statusNote] = fundingStatusText(r.fundedPct);
    $('fundingStatus').textContent = status;
    $('fundingStatusNote').textContent = statusNote;

    $('todayVsRetirement').textContent = `${formatINR(r.currentTodayExpense, true)}/mo → ${formatINR(r.retirementLifestyleToday, true)}/mo`;
    $('todayVsFutureRetirement').textContent = `${formatINR(r.retirementLifestyleToday, true)}/mo → ${formatINR(r.retirementLifestyleFuture, true)}/mo`;
    $('todayVsFutureLabel').textContent = `Same retirement lifestyle: today's money → at retirement (age ${Math.round(s.retirementAge)}) in future ${currencyCode()}`;
    $('todayVsRetirementNote').textContent = s.mode === 'quick'
      ? "Today's spending versus your selected retirement-spending percentage, both shown in today's purchasing power."
      : "Today's listed spending versus the first retirement-year lifestyle, before future inflation is applied.";
    const lifestyleDeltaPct = r.currentTodayExpense > 0 ? ((r.retirementLifestyleToday - r.currentTodayExpense) / r.currentTodayExpense) * 100 : 0;
    const narrative = $('budgetNarrative');
    if (narrative) {
      if (Math.abs(lifestyleDeltaPct) < 1) narrative.textContent = "Your retirement lifestyle is currently set to be about the same as today's spending, before future inflation.";
      else if (lifestyleDeltaPct < 0) narrative.textContent = `Based on these inputs, the retirement lifestyle is ${Math.abs(lifestyleDeltaPct).toFixed(0)}% lower than today's listed spending in today's purchasing power.`;
      else narrative.textContent = `Based on these inputs, the retirement lifestyle is ${lifestyleDeltaPct.toFixed(0)}% higher than today's listed spending in today's purchasing power.`;
    }
    $('monthlyReduced').textContent = `${formatINR(r.monthlyReduced, true)}/mo`;
    $('monthlyIncreased').textContent = `${formatINR(r.monthlyIncreased, true)}/mo`;

    $('quickTodayRetirementBudget').textContent = `${formatINR(s.quickMonthlyExpense * s.quickRetirementPct / 100)}/mo`;
    $('detailedExpenseTotal').textContent = formatINR(s.expenses.reduce((a,e) => a + Math.max(0,e.amount), 0));

    $('glanceTodaySpend').textContent = `${formatINR(r.currentTodayExpense, true)}/mo`;
    $('glanceRetirementSpend').textContent = `${formatINR(r.retirementLifestyleToday, true)}/mo`;
    $('glanceFutureSpend').textContent = `${formatINR(r.retirementLifestyleFuture, true)}/mo`;
    $('glanceFutureSpendLabel').textContent = `Projected monthly spending at retirement (age ${Math.round(s.retirementAge)})`;
    $('glanceReduced').textContent = `${formatINR(r.monthlyReduced, true)}/mo`;
    $('glanceIncreased').textContent = `${formatINR(r.monthlyIncreased, true)}/mo`;

    $('breakdownExpensePV').textContent = formatINR(r.recurringExpensePV, true);
    $('breakdownIncomePV').textContent = `−${formatINR(r.retirementIncomePV, true)}`;
    $('breakdownGoalsPV').textContent = formatINR(r.goalsPV, true);
    $('breakdownBuffer').textContent = formatINR(r.safetyBufferAmount, true);
    $('breakdownTotal').textContent = formatINR(r.requiredCorpus, true);
    renderExpenseChanges(r);
    renderPlanInsights(r);

    renderLineChart($('expenseChart'), r.expensePoints, {
      retirementAge: s.retirementAge, valueFormatter: v => formatINR(v, true), yLabel: 'Monthly spending',
      primaryLabel: 'Monthly spending', interactive: true
    });
    const depletionMarker = r.projectedDepletionAge !== null && r.projectedDepletionAge < s.planningAge - 0.05
      ? [{
          age: Math.max(s.retirementAge, r.projectedDepletionAge),
          value: 0,
          title: `Current plan reaches ${formatINR(0)}`,
          subtitle: `Around ${formatAgeCompact(Math.max(s.retirementAge, r.projectedDepletionAge))}`,
          color: '#b93838'
        }]
      : [];
    renderLineChart($('portfolioChart'), r.portfolioPoints, {
      retirementAge: null, valueFormatter: v => formatINR(v, true), yLabel: '',
      axisTitle: `Portfolio balance (nominal ${currencyCode()})`,
      primaryLabel: 'Fully funded target path', compareLabel: 'Your current-plan path', comparePoints: r.currentPortfolioPoints, interactive: true,
      primaryColor: '#123f5f', compareColor: '#0e827a', verticalMarkers: depletionMarker,
      startPointLabels: true, showGapAtStart: true
    });
    $('portfolioChartCaption').textContent = `How to read this chart: the green line starts with the retirement savings projected from your current savings and contributions (${formatINR(r.projectedCorpus, true)}). The blue line starts with the modelled retirement target (${formatINR(r.requiredCorpus, true)}), including your ${s.bufferRate.toFixed(0)}% safety buffer (${formatINR(r.safetyBufferAmount, true)}). Any unused reserve remains invested and may continue to grow, so the blue path may finish above zero.${depletionMarker.length ? ` The red marker shows the current-plan portfolio reaching zero around ${formatAgeYearsMonths(depletionMarker[0].age, true)}.` : ' The current-plan portfolio does not reach zero before the selected planning age.'}`;
    $('expenseChartCaption').textContent = s.mode === 'detailed' ? 'Shows the full expense path, including costs that continue, change, start or end' : 'Quick mode applies your chosen retirement spending percentage';
    renderScenarios(s);
    buildPrintReport(r);
  }

  function renderLineChart(container, points, opts = {}) {
    const comparePoints = Array.isArray(opts.comparePoints) ? opts.comparePoints : [];
    const allPoints = [...(points || []), ...comparePoints];
    if (!points || points.length < 2 || allPoints.some(p => !Number.isFinite(p.value) || !Number.isFinite(p.age))) {
      container.innerHTML = '<div class="chart-empty">Not enough valid data to draw this chart.</div>';
      return;
    }

    const hasAxisTitle = Boolean(opts.axisTitle);
    const hasPointLabels = Array.isArray(opts.labelPoints) && opts.labelPoints.length > 0;
    const W = 720, H = 300, L = hasAxisTitle ? 86 : 64, R = 18, T = comparePoints.length ? 42 : (hasPointLabels ? 48 : 20), B = 52;
    const xs = allPoints.map(p => p.age), ys = allPoints.map(p => Math.max(0, p.value));
    const minX = Math.min(...xs), maxX = Math.max(...xs);
    const maxYRaw = Math.max(...ys, 1);

    // Human-friendly chart scale: prefer rounded values rather than awkward mathematical intervals.
    // The locale formatter then presents those values in the selected currency.
    const niceStep = (maxValue, targetIntervals = 5) => {
      const rough = Math.max(1e-9, maxValue / Math.max(1, targetIntervals));
      const magnitude = Math.pow(10, Math.floor(Math.log10(rough)));
      const normalized = rough / magnitude;
      const niceNormalized = normalized <= 1 ? 1 : normalized <= 2 ? 2 : normalized <= 2.5 ? 2.5 : normalized <= 5 ? 5 : 10;
      return niceNormalized * magnitude;
    };
    const yStep = niceStep(maxYRaw, 5);
    const maxY = Math.max(yStep, Math.ceil(maxYRaw / yStep) * yStep);

    const x = v => L + (v - minX) / Math.max(1e-9, maxX - minX) * (W - L - R);
    const y = v => T + (1 - Math.max(0, v) / maxY) * (H - T - B);
    const polyline = list => list.map(p => `${x(p.age).toFixed(1)},${y(p.value).toFixed(1)}`).join(' ');
    const primaryColor = opts.primaryColor || '#0e827a';
    const compareColor = opts.compareColor || '#d8a83b';
    const retirementLine = opts.retirementAge && opts.retirementAge > minX && opts.retirementAge < maxX
      ? `<line x1="${x(opts.retirementAge)}" y1="${T}" x2="${x(opts.retirementAge)}" y2="${H-B}" stroke="#d8a83b" stroke-width="1.5" stroke-dasharray="5 5"/><text x="${x(opts.retirementAge)+5}" y="${T+13}" font-size="11" fill="#856112">Retire ${opts.retirementAge}</text>` : '';

    const verticalMarkers = Array.isArray(opts.verticalMarkers) ? opts.verticalMarkers.filter(m => Number.isFinite(m.age) && m.age > minX && m.age < maxX) : [];
    const depletionShade = opts.shadeAfterMarker && verticalMarkers.length ? (() => {
      const first = [...verticalMarkers].sort((a,b) => a.age - b.age)[0];
      const sx = x(first.age);
      return `<rect x="${sx}" y="${T}" width="${Math.max(0, W-R-sx)}" height="${H-T-B}" fill="#fff3f1" opacity="0.72"/>`;
    })() : '';
    const markerLines = verticalMarkers.map((m, idx) => {
      const mx = x(m.age);
      const color = m.color || '#b93838';
      const title = escapeXml(m.title || m.label || `Age ${Math.round(m.age)}`);
      const subtitle = escapeXml(m.subtitle || '');
      const labelWidth = 148;
      const labelHeight = subtitle ? 28 : 19;
      const bx = Math.max(L + 4, Math.min(W - R - labelWidth, mx - labelWidth / 2));
      const by = T + 4 + idx * (labelHeight + 4);
      const markerDot = Number.isFinite(m.value) ? `<circle cx="${mx}" cy="${y(m.value)}" r="5" fill="${color}" stroke="${color}" stroke-width="1"/>` : '';
      const subLine = subtitle ? `<text x="${bx+8}" y="${by+22}" font-size="8.0" font-weight="700" fill="${color}">${subtitle}</text>` : '';
      return `<line x1="${mx}" y1="${T}" x2="${mx}" y2="${H-B}" stroke="${color}" stroke-width="1.6" stroke-dasharray="5 4"/>` +
        `<rect x="${bx}" y="${by}" width="${labelWidth}" height="${labelHeight}" rx="7" fill="#fff0ee" stroke="#e5b6b0"/>` +
        `<text x="${bx+8}" y="${by+12}" font-size="8.2" font-weight="850" fill="${color}">${title}</text>${subLine}${markerDot}`;
    }).join('');

    const tickValues = [];
    for (let v = 0; v <= maxY + yStep * 0.001; v += yStep) tickValues.push(v);
    const yGrid = tickValues.map(v => `<line x1="${L}" y1="${y(v)}" x2="${W-R}" y2="${y(v)}" stroke="#e7edf1"/><text x="${L-8}" y="${y(v)+4}" text-anchor="end" font-size="10" fill="#748292">${escapeXml(opts.valueFormatter ? opts.valueFormatter(v) : String(Math.round(v)))}</text>`).join('');
    const axisTitle = hasAxisTitle ? `<text x="18" y="${T + (H-T-B)/2}" text-anchor="middle" font-size="10.5" font-weight="700" fill="#596879" transform="rotate(-90 18 ${T + (H-T-B)/2})">${escapeXml(opts.axisTitle)}</text>` : '';

    const xTickValues = opts.retirementAge && opts.retirementAge > minX && opts.retirementAge < maxX
      ? [minX, opts.retirementAge, maxX]
      : [minX, (minX + maxX) / 2, maxX];
    const xTicks = [...new Set(xTickValues.map(v => Math.round(v)))].map(v => `<text x="${x(v)}" y="${H-20}" text-anchor="middle" font-size="10" fill="#748292">Age ${Math.round(v)}</text>`).join('');
    const legend = comparePoints.length ? `<g font-size="10" fill="#536276">
      <line x1="${L}" y1="16" x2="${L+22}" y2="16" stroke="${primaryColor}" stroke-width="4"/><text x="${L+28}" y="20">${escapeXml(opts.primaryLabel || 'Required corpus')}</text>
      <line x1="${L+200}" y1="16" x2="${L+222}" y2="16" stroke="${compareColor}" stroke-width="4"/><text x="${L+228}" y="20">${escapeXml(opts.compareLabel || 'Your current plan')}</text>
    </g>` : '';
    const comparePolyline = comparePoints.length ? `<polyline fill="none" stroke="${compareColor}" stroke-width="3.5" stroke-linejoin="round" stroke-linecap="round" points="${polyline(comparePoints)}"/>` : '';

    let startLabels = '';
    if (opts.startPointLabels && comparePoints.length) {
      const a = points[0], b = comparePoints[0];
      const fmt = opts.valueFormatter || String;
      const ax = x(a.age) + 10, ay = Math.max(T + 29, y(a.value) - 24);
      const bx = x(b.age) + 10, by = Math.min(H - B - 22, y(b.value) + 7);
      startLabels = `<g font-size="9.2" font-weight="800">` +
        `<rect x="${ax}" y="${ay}" width="164" height="19" rx="7" fill="#f3f7fa" stroke="#cbd9e2"/><text x="${ax+8}" y="${ay+13}" fill="${primaryColor}">Target: ${escapeXml(fmt(a.value))}</text>` +
        `<rect x="${bx}" y="${by}" width="164" height="19" rx="7" fill="#eef8f6" stroke="#b9ddd7"/><text x="${bx+8}" y="${by+13}" fill="${compareColor}">Current plan: ${escapeXml(fmt(b.value))}</text></g>`;
    }

    const requestedLabels = Array.isArray(opts.labelPoints) ? opts.labelPoints.filter(p => Number.isFinite(p?.age) && Number.isFinite(p?.value)) : [];
    const placedLabelBoxes = [];
    const labelGap = 8;
    const overlapsLabel = (a, b) => !(a.x + a.w + labelGap <= b.x || b.x + b.w + labelGap <= a.x || a.y + a.h + labelGap <= b.y || b.y + b.h + labelGap <= a.y);
    const pointLabels = requestedLabels.map((p, idx) => {
      const px = x(p.age), py = y(p.value);
      const rawValue = p.labelValue || (opts.valueFormatter || String)(p.value);
      const titleRaw = p.labelTitle || `Age ${Math.round(p.age)}`;
      const titleText = escapeXml(titleRaw);
      const valueText = escapeXml(rawValue);
      const longest = Math.max(titleRaw.length, String(rawValue).length);
      const boxW = Math.max(72, Math.min(122, longest * 4.7 + 16));
      const boxH = 28;
      const nearRight = px > W - 135;
      let preferLeft = p.labelSide === 'left' || (p.labelSide !== 'right' && nearRight);
      if (nearRight) preferLeft = true;
      let bx = preferLeft ? px - boxW - 10 : px + 10;
      let by = py - boxH - 10;
      by = Math.max(4, Math.min(H - B - boxH - 2, by));

      // PDF labels cannot be hovered or moved, so reserve a real visual gap between
      // adjacent milestone boxes. If two boxes would touch, stack the newer one
      // further above the line while keeping it on the same side where possible.
      let box = { x: bx, y: by, w: boxW, h: boxH };
      let attempts = 0;
      while (placedLabelBoxes.some(prev => overlapsLabel(box, prev)) && attempts < 5) {
        const candidateY = by - (boxH + labelGap);
        if (candidateY >= 4) {
          by = candidateY;
        } else {
          preferLeft = !preferLeft;
          bx = preferLeft ? px - boxW - 10 : px + 10;
          by = Math.max(4, py - boxH - 10);
        }
        box = { x: bx, y: by, w: boxW, h: boxH };
        attempts += 1;
      }
      placedLabelBoxes.push(box);
      return `<g><circle cx="${px}" cy="${py}" r="4.2" fill="${primaryColor}" stroke="#ffffff" stroke-width="1.4"/>` +
        `<rect x="${bx}" y="${by}" width="${boxW}" height="${boxH}" rx="6" fill="#f3f9f8" stroke="#b8ddd7"/>` +
        `<text x="${bx+7}" y="${by+11}" font-size="7.8" font-weight="750" fill="#40566e">${titleText}</text>` +
        `<text x="${bx+7}" y="${by+22}" font-size="8.6" font-weight="850" fill="${primaryColor}">${valueText}</text></g>`;
    }).join('');

    const primaryArea = opts.areaFill ? (() => {
      const coords = points.map(p => `${x(p.age).toFixed(1)},${y(p.value).toFixed(1)}`).join(' ');
      return `<polygon points="${x(points[0].age).toFixed(1)},${(H-B).toFixed(1)} ${coords} ${x(points[points.length-1].age).toFixed(1)},${(H-B).toFixed(1)}" fill="${primaryColor}" opacity="0.08"/>`;
    })() : '';
    const gapAnnotation = opts.showGapAtStart && comparePoints.length ? (() => {
      const p = points[0], c = comparePoints[0];
      const gap = Math.max(0, p.value - c.value);
      if (gap <= 0) return '';
      const gx = Math.min(W-R-95, x(p.age) + 68);
      const y1 = y(p.value), y2 = y(c.value);
      const mid = (y1+y2)/2;
      const fmt = opts.valueFormatter || (v => String(Math.round(v)));
      return `<g><line x1="${gx}" y1="${y1}" x2="${gx}" y2="${y2}" stroke="#c18a22" stroke-width="1.7"/>` +
        `<line x1="${gx-5}" y1="${y1}" x2="${gx+5}" y2="${y1}" stroke="#c18a22" stroke-width="1.7"/>` +
        `<line x1="${gx-5}" y1="${y2}" x2="${gx+5}" y2="${y2}" stroke="#c18a22" stroke-width="1.7"/>` +
        `<rect x="${gx+7}" y="${mid-9}" width="98" height="18" rx="6" fill="#fff7e7" stroke="#ead6a7"/>` +
        `<text x="${gx+13}" y="${mid+3}" font-size="8.6" font-weight="800" fill="#7a5716">Gap ${escapeXml(fmt(gap))}</text></g>`;
    })() : '';
    const endPointLabels = opts.endPointLabels && comparePoints.length ? (() => {
      const fmt = opts.valueFormatter || (v => String(Math.round(v)));
      const p = points[points.length-1], c = comparePoints[comparePoints.length-1];
      const px = x(p.age), py = y(p.value), cx = x(c.age), cy = y(c.value);
      const boxW = 158, boxH = 29;
      const pBx = Math.max(L+6, px-boxW-8), pBy = Math.max(T+35, py-boxH-7);
      const current = c.value > 0 ? (() => {
        const cBx = Math.max(L+6, cx-boxW-8), cBy = Math.max(T+35, cy-boxH-7);
        return `<rect x="${cBx}" y="${cBy}" width="${boxW}" height="${boxH}" rx="6" fill="#eef8f6" stroke="#b9ddd7"/>` +
          `<text x="${cBx+7}" y="${cBy+11}" font-size="7.6" font-weight="750" fill="#40566e">Current-plan balance at age ${Math.round(c.age)}</text>` +
          `<text x="${cBx+7}" y="${cBy+23}" font-size="8.6" font-weight="850" fill="${compareColor}">${escapeXml(fmt(c.value))}</text>`;
      })() : '';
      return `<g><rect x="${pBx}" y="${pBy}" width="${boxW}" height="${boxH}" rx="6" fill="#f3f7fa" stroke="#cbd9e2"/>` +
        `<text x="${pBx+7}" y="${pBy+11}" font-size="7.6" font-weight="750" fill="#40566e">Target-funded balance at age ${Math.round(p.age)}</text>` +
        `<text x="${pBx+7}" y="${pBy+23}" font-size="8.6" font-weight="850" fill="${primaryColor}">${escapeXml(fmt(p.value))} remaining</text>${current}</g>`;
    })() : '';
    const tooltip = opts.interactive === false ? '' : '<div class="chart-tooltip" aria-hidden="true"></div>';
    container.innerHTML = `${tooltip}<svg viewBox="0 0 ${W} ${H}" role="presentation" aria-hidden="true">
      ${legend}${axisTitle}${yGrid}${depletionShade}${retirementLine}${markerLines}${primaryArea}
      <polyline fill="none" stroke="${primaryColor}" stroke-width="4" stroke-linejoin="round" stroke-linecap="round" points="${polyline(points)}"/>
      ${comparePolyline}
      <circle cx="${x(points[0].age)}" cy="${y(points[0].value)}" r="4.2" fill="${primaryColor}" stroke="${primaryColor}" stroke-width="1"/>
      <circle cx="${x(points[points.length-1].age)}" cy="${y(points[points.length-1].value)}" r="4.2" fill="${primaryColor}" stroke="${primaryColor}" stroke-width="1"/>
      ${comparePoints.length ? `<circle cx="${x(comparePoints[0].age)}" cy="${y(comparePoints[0].value)}" r="4.2" fill="${compareColor}" stroke="${compareColor}" stroke-width="1"/>` : ''}
      ${gapAnnotation}${startLabels}${pointLabels}${endPointLabels}${xTicks}
      ${opts.yLabel ? `<text x="${L}" y="${H-4}" font-size="10" fill="#8995a2">${escapeXml(opts.yLabel)}</text>` : ''}
      <line class="chart-hover-line" x1="0" y1="${T}" x2="0" y2="${H-B}" stroke="#9aa7b4" stroke-width="1" stroke-dasharray="3 3" visibility="hidden"/>
      <circle class="chart-hover-dot chart-hover-primary" cx="0" cy="0" r="5" fill="${primaryColor}" stroke="#fff" stroke-width="2" visibility="hidden"/>
      ${comparePoints.length ? `<circle class="chart-hover-dot chart-hover-compare" cx="0" cy="0" r="5" fill="${compareColor}" stroke="#fff" stroke-width="2" visibility="hidden"/>` : ''}
    </svg>`;

    if (opts.interactive === false) return;
    const svg = container.querySelector('svg');
    const tip = container.querySelector('.chart-tooltip');
    if (!svg || !tip) return;
    const hoverLine = svg.querySelector('.chart-hover-line');
    const primaryDot = svg.querySelector('.chart-hover-primary');
    const compareDot = svg.querySelector('.chart-hover-compare');

    const interpolate = (list, age) => {
      if (!list.length) return null;
      if (age <= list[0].age) return { age, value: list[0].value };
      if (age >= list[list.length - 1].age) return { age, value: list[list.length - 1].value };
      const exact = list.find(p => Math.abs(p.age - age) < 1e-7);
      if (exact) return { age: exact.age, value: exact.value };
      for (let i = 1; i < list.length; i++) {
        if (list[i].age >= age) {
          const a = list[i-1], b = list[i];
          const ratio = (age - a.age) / Math.max(1e-9, b.age - a.age);
          return { age, value: a.value + (b.value - a.value) * ratio };
        }
      }
      return { age, value: list[list.length - 1].value };
    };

    const hide = () => {
      tip.classList.remove('visible');
      hoverLine?.setAttribute('visibility','hidden');
      primaryDot?.setAttribute('visibility','hidden');
      compareDot?.setAttribute('visibility','hidden');
    };
    const show = (event) => {
      const rect = svg.getBoundingClientRect();
      if (!rect.width) return;
      const pointerX = Math.max(0, Math.min(rect.width, event.clientX - rect.left));
      const viewX = pointerX / rect.width * W;
      const rawAge = minX + (viewX - L) / Math.max(1e-9, W - L - R) * (maxX - minX);

      // Snap to a depletion marker when the pointer is close to it; otherwise use the
      // nearest whole-year point from the primary path. This prevents a zero-balance marker
      // from showing the previous annual balance in the tooltip.
      const closeMarker = verticalMarkers.find(m => Math.abs(x(m.age) - viewX) <= 11);
      let selectedAge;
      if (closeMarker) selectedAge = closeMarker.age;
      else {
        const nearestPrimary = points.reduce((best, p) => Math.abs(p.age - rawAge) < Math.abs(best.age - rawAge) ? p : best, points[0]);
        selectedAge = nearestPrimary.age;
      }

      const p1 = interpolate(points, selectedAge);
      const p2 = comparePoints.length ? interpolate(comparePoints, selectedAge) : null;
      const cx = x(selectedAge);
      hoverLine?.setAttribute('x1', cx); hoverLine?.setAttribute('x2', cx); hoverLine?.setAttribute('visibility','visible');
      primaryDot?.setAttribute('cx', cx); primaryDot?.setAttribute('cy', y(p1.value)); primaryDot?.setAttribute('visibility','visible');
      if (p2 && compareDot) { compareDot.setAttribute('cx', cx); compareDot.setAttribute('cy', y(p2.value)); compareDot.setAttribute('visibility','visible'); }
      const fmt = opts.valueFormatter || (v => String(Math.round(v)));
      const ageLabel = Math.abs(selectedAge - Math.round(selectedAge)) < 1e-7 ? `Age ${Math.round(selectedAge)}` : `Age ${formatAgeYearsMonths(selectedAge)}`;
      const startGap = opts.showGapAtStart && p2 && Math.abs(selectedAge - minX) < 1e-7
        ? `<span>Funding gap: ${escapeXml(fmt(Math.max(0, p1.value - p2.value)))}</span>` : '';
      tip.innerHTML = `<strong>${escapeXml(ageLabel)}${Math.abs(selectedAge - minX) < 1e-7 ? ' — Retirement starts' : ''}</strong><span>${escapeXml(opts.primaryLabel || opts.yLabel || 'Value')}: ${escapeXml(fmt(p1.value))}</span>${p2 ? `<span>${escapeXml(opts.compareLabel || 'Comparison')}: ${escapeXml(fmt(p2.value))}</span>` : ''}${startGap}`;
      const left = Math.min(container.clientWidth - 205, Math.max(8, event.clientX - container.getBoundingClientRect().left + 12));
      const top = Math.max(8, event.clientY - container.getBoundingClientRect().top - 66);
      tip.style.left = `${left}px`; tip.style.top = `${top}px`; tip.classList.add('visible');
    };
    svg.addEventListener('pointermove', show);
    svg.addEventListener('pointerdown', show);
    svg.addEventListener('pointerleave', hide);
  }

  function escapeXml(s) { return String(s).replace(/[<>&'\"]/g, c => ({'<':'&lt;','>':'&gt;','&':'&amp;',"'":'&apos;','"':'&quot;'}[c])); }

  function scenarioResults(s) {
    return [s.retirementAge - 5, s.retirementAge, s.retirementAge + 5]
      .map(a => Math.round(a))
      .filter((a, i, arr) => a > s.currentAge && a < s.planningAge && arr.indexOf(a) === i)
      .map(age => ({ age, result: calculatePlan({ ...s, retirementAge: age }) }))
      .filter(x => !x.result.errors?.length);
  }

  function renderScenarios(s) {
    const grid = $('scenarioGrid');
    const scenarios = scenarioResults(s);
    grid.innerHTML = '';
    for (const { age, result: scenario } of scenarios) {
      const current = age === Math.round(s.retirementAge);
      const card = document.createElement('article');
      card.className = `scenario-item ${current ? 'current' : ''}`;
      card.innerHTML = `<span class="scenario-age">Retire at ${age}${current ? ' · current choice' : ''}</span>
        <span class="scenario-corpus-label">Retirement target at age ${age} (future ${currencyCode()})</span>
        <strong>${formatINR(scenario.requiredCorpus, true)}</strong>
        <dl>
          <div><dt>Years to save</dt><dd>${age - s.currentAge}</dd></div>
          <div><dt>${escapeXml(requiredContributionLabelText(s.contributionFrequency, 'Total'))}</dt><dd>${escapeXml(contributionText(scenario.totalMonthlyNeeded, s.contributionFrequency))}</dd></div>
          <div><dt>Projected funding</dt><dd>${Math.min(999, Math.max(0, scenario.fundedPct)).toFixed(0)}%</dd></div>
        </dl>
        ${current ? '<span class="current-scenario-note">Your selected retirement age</span>' : `<button type="button" class="scenario-use-button no-print" data-retirement-age="${age}">Use age ${age}</button>`}`;
      grid.appendChild(card);
    }
    const takeaway = $('scenarioTakeaway');
    if (takeaway) {
      const current = scenarios.find(x => x.age === Math.round(s.retirementAge));
      const later = scenarios.filter(x => x.age > Math.round(s.retirementAge)).sort((a,b) => a.age - b.age)[0];
      if (current && later) {
        const contributionReduction = current.result.totalMonthlyNeeded - later.result.totalMonthlyNeeded;
        const corpusChange = later.result.requiredCorpus - current.result.requiredCorpus;
        takeaway.innerHTML = `<span>One lever to explore</span><strong>Model retirement at age ${later.age}</strong><p>Under the same assumptions, the modelled recurring retirement contribution changes from <b>${escapeXml(contributionText(current.result.totalMonthlyNeeded, s.contributionFrequency))}</b> to <b>${escapeXml(contributionText(later.result.totalMonthlyNeeded, s.contributionFrequency))}</b>${contributionReduction > 0 ? ` — about <b>${escapeXml(contributionText(contributionReduction, s.contributionFrequency))} lower</b>` : ''}. The nominal corpus at retirement ${corpusChange >= 0 ? 'rises' : 'falls'} by about ${escapeXml(formatINR(Math.abs(corpusChange), true))} because each retirement target is shown in future money at its own retirement date. This is a scenario comparison, not a recommendation.</p>`;
      } else {
        takeaway.innerHTML = '<span>One lever to explore</span><strong>Change the retirement age</strong><p>Use the comparison cards above to see how a different retirement date changes the years available to save, required recurring retirement contribution and nominal corpus.</p>';
      }
    }
  }

  function reportAssumptions(s) {
    const assumptions = [
      ['Country / region', regionLabel()],
      ['Currency', currencyCode()],
      ['Planner mode', s.mode === 'detailed' ? 'Detailed expense planner' : 'Quick estimate'],
      ['Current age', `${Math.round(s.currentAge)}`],
      ['Retirement age', `${Math.round(s.retirementAge)}`],
      ['Plan until age', `${Math.round(s.planningAge)}`],
      ['Current retirement savings', formatINR(s.currentSavings)],
      ['Pay frequency', frequencyLabel(s.payFrequency)],
      ['Retirement contribution frequency', frequencyLabel(s.contributionFrequency)],
      [currentContributionLabelText(s.contributionFrequency), contributionText(s.currentMonthlyInvestment, s.contributionFrequency)],
      ['Return before retirement', `${s.preReturn.toFixed(1)}% p.a.`],
      ['Return during retirement', `${s.postReturn.toFixed(1)}% p.a.`],
      ['Safety buffer', `${s.bufferRate.toFixed(0)}%`],
    ];
    if (s.mode === 'quick') {
      assumptions.push(['Current household expenses', `${formatINR(s.quickMonthlyExpense)}/mo`]);
      assumptions.push(['Spending remaining at retirement', `${s.quickRetirementPct.toFixed(0)}%`]);
      assumptions.push(['Inflation', `${s.quickInflation.toFixed(1)}% p.a.`]);
    } else {
      assumptions.push(['General inflation', `${s.generalInflation.toFixed(1)}% p.a.`]);
      assumptions.push(['Healthcare inflation', `${s.healthInflation.toFixed(1)}% p.a.`]);
      assumptions.push(['Lifestyle inflation', `${s.lifestyleInflation.toFixed(1)}% p.a.`]);
      assumptions.push(['Education inflation', `${s.educationInflation.toFixed(1)}% p.a.`]);
    }
    return assumptions;
  }

  function buildRetirementReportModel(r) {
    const s = r.s;
    const generatedAt = new Date();
    const monthsToRetire = Math.max(0, Math.round((s.retirementAge - s.currentAge) * 12));
    const contributionPrincipal = s.currentMonthlyInvestment * (r.contributionPeriods ?? contributionSchedule(s.preReturn, s.retirementAge - s.currentAge, s.contributionFrequency).periods);
    const modelledInvestmentGrowth = r.projectedCorpus - s.currentSavings - contributionPrincipal;
    const inflationMultiple = r.retirementLifestyleToday > 0 ? r.retirementLifestyleFuture / r.retirementLifestyleToday : 1;
    const [fundingStatus, fundingStatusNote] = fundingStatusText(r.fundedPct);
    const assumptions = reportAssumptions(s);
    const methodology = {
      id: APP_CONFIG.METHODOLOGY_ID || 'retirement-methodology-current',
      label: APP_CONFIG.METHODOLOGY_LABEL || 'Current retirement methodology',
      url: APP_CONFIG.METHODOLOGY_URL || 'https://carrowmont.com/retirement-calculator/methodology.html'
    };
    const spec = {
      schemaVersion: APP_CONFIG.REPORT_SCHEMA_VERSION || '1.0',
      toolId: 'retirement',
      toolName: 'Carrowmont Retirement Planner',
      generatedAt,
      locale: L ? L.getLocale() : 'en-IN',
      country: regionLabel(),
      currency: currencyCode(),
      methodology,
      inputs: {
        mode: s.mode,
        currentAge: s.currentAge,
        retirementAge: s.retirementAge,
        planningAge: s.planningAge,
        currentSavings: s.currentSavings,
        payFrequency: s.payFrequency,
        contributionFrequency: s.contributionFrequency,
        currentMonthlyInvestment: s.currentMonthlyInvestment,
        preReturn: s.preReturn,
        postReturn: s.postReturn,
        bufferRate: s.bufferRate
      },
      calculatedResults: {
        requiredCorpus: r.requiredCorpus,
        projectedCorpus: r.projectedCorpus,
        gap: r.gap,
        fundedPct: r.fundedPct,
        totalMonthlyNeeded: r.totalMonthlyNeeded,
        extraMonthlyNeeded: r.extraMonthlyNeeded,
        currentTodayExpense: r.currentTodayExpense,
        retirementLifestyleToday: r.retirementLifestyleToday,
        retirementLifestyleFuture: r.retirementLifestyleFuture,
        firstYearExpense: r.firstYearExpense,
        firstYearIncome: r.firstYearIncome,
        recurringExpensePV: r.recurringExpensePV,
        retirementIncomePV: r.retirementIncomePV,
        goalsPV: r.goalsPV,
        safetyBufferAmount: r.safetyBufferAmount,
        futureExisting: r.futureExisting,
        futureCurrentContrib: r.futureCurrentContrib,
        projectedDepletionAge: r.projectedDepletionAge
      },
      assumptions: assumptions.map(([label, value]) => ({ label, value })),
      extras: {
        fundingStatus,
        fundingStatusNote,
        monthsToRetire,
        contributionPrincipal,
        modelledInvestmentGrowth,
        inflationMultiple,
        expenseChanges: r.expenseChanges,
        expensePoints: r.expensePoints,
        portfolioPoints: r.portfolioPoints,
        currentPortfolioPoints: r.currentPortfolioPoints
      }
    };
    const model = REPORT_ENGINE ? REPORT_ENGINE.createReportModel(spec) : spec;
    window.__CARROWMONT_LAST_REPORT_MODEL = model;
    return model;
  }

  function reportRow(label, value, valueClass = '') {
    return `<tr><th>${escapeXml(label)}</th><td class="${valueClass}">${escapeXml(value)}</td></tr>`;
  }

  function buildPrintReport(r) {
    const s = r.s;
    const model = buildRetirementReportModel(r);
    $('reportGenerated').textContent = `Generated ${model.generatedDisplay || model.generatedDate || ''}`;
    $('reportPlannerMode').textContent = s.mode === 'detailed' ? 'Based on: Detailed estimate' : 'Based on: Quick estimate';
    const quickModeNote = $('reportQuickModeNote');
    if (quickModeNote) quickModeNote.style.display = s.mode === 'quick' ? '' : 'none';
    $('reportCorpusLabel').textContent = `Estimated retirement requirement (future ${currencyCode()} at retirement)`;
    $('reportTodaySpendLabel').textContent = `Current monthly spending`;
    $('reportRetirementSpendLabel').textContent = `Retirement lifestyle (today's ${currencyCode()})`;
    $('reportProjectedCorpusLabel').textContent = `Projected savings at retirement (future ${currencyCode()})`;
    $('reportFundingGapLabel').textContent = `Funding gap at retirement (future ${currencyCode()})`;
    $('reportMonthlyNeededLabel').textContent = requiredContributionLabelText(s.contributionFrequency, 'Total') + ' from now';
    $('reportTargetBasis').textContent = `Future ${currencyCode()} at retirement unless noted`;
    $('reportFundingBasis').textContent = `Future ${currencyCode()} at retirement unless noted`;
    $('reportCorpus').textContent = formatINR(r.requiredCorpus, true);
    $('reportRetireLine').textContent = `Retire at age ${Math.round(s.retirementAge)} · plan through age ${Math.round(s.planningAge)}`;
    $('reportMonthlyNeeded').textContent = contributionText(r.totalMonthlyNeeded, s.contributionFrequency);
    $('reportTodaySpend').textContent = `${formatINR(r.currentTodayExpense)}/mo`;
    $('reportRetirementSpend').textContent = `${formatINR(r.retirementLifestyleToday)}/mo`;
    $('reportFutureSpend').textContent = `${formatINR(r.retirementLifestyleFuture)}/mo`;
    $('reportFutureSpendLabel').textContent = `Projected monthly spending at retirement (age ${Math.round(s.retirementAge)}, future ${currencyCode()})`;
    $('reportProjectedCorpus').textContent = formatINR(r.projectedCorpus, true);
    $('reportFundingGap').textContent = r.gap > 0 ? formatINR(r.gap, true) : 'No gap*';
    $('reportFundedPct').textContent = `${Math.max(0, r.fundedPct).toFixed(0)}%`;
    const [reportStatus, reportStatusNote] = fundingStatusText(r.fundedPct);
    $('reportFundingStatus').textContent = reportStatus;
    $('reportExecutiveNote').textContent = reportStatusNote;
    $('reportFirstYearExpense').textContent = `${formatINR(r.firstYearExpense)}/mo`;
    $('reportFirstYearIncome').textContent = r.firstYearIncome > 0 ? `${formatINR(r.firstYearIncome)}/mo` : 'None entered';
    $('reportReduced').textContent = `${formatINR(r.monthlyReduced)}/mo`;
    $('reportIncreased').textContent = `${formatINR(r.monthlyIncreased)}/mo`;

    $('reportCurrentMonthlyInvestment').textContent = contributionText(s.currentMonthlyInvestment, s.contributionFrequency);
    if ($('reportContributionSectionTitle')) { const title = requiredContributionLabelText(s.contributionFrequency, 'Total').replace(/^Total /, ''); $('reportContributionSectionTitle').textContent = title.charAt(0).toUpperCase() + title.slice(1) + ' by the model'; }
    if ($('reportCurrentContributionLabel')) $('reportCurrentContributionLabel').textContent = currentContributionLabelText(s.contributionFrequency);
    if ($('reportNeededContributionLabel')) $('reportNeededContributionLabel').textContent = requiredContributionLabelText(s.contributionFrequency, 'Total') + ' from now';
    if ($('reportAdditionalContributionLabel')) $('reportAdditionalContributionLabel').textContent = requiredContributionLabelText(s.contributionFrequency, 'Additional');
    $('reportNeededMonthlyInvestment').textContent = contributionText(r.totalMonthlyNeeded, s.contributionFrequency);
    $('reportAdditionalMonthlyInvestment').textContent = r.extraMonthlyNeeded > 1 ? contributionText(r.extraMonthlyNeeded, s.contributionFrequency) : `${zeroMoney()} under assumptions`;
    const additionalRibbon = $('reportAdditionalRibbon');
    if (additionalRibbon) {
      additionalRibbon.classList.toggle('report-action-ribbon-gap', r.extraMonthlyNeeded > 1);
      additionalRibbon.classList.toggle('report-action-ribbon-ok', !(r.extraMonthlyNeeded > 1));
    }
    $('reportActionNarrative').textContent = r.extraMonthlyNeeded > 1
      ? `Under the entered assumptions, increasing the retirement contribution from ${contributionText(s.currentMonthlyInvestment, s.contributionFrequency)} to about ${contributionText(r.totalMonthlyNeeded, s.contributionFrequency)} may close the modelled gap by age ${Math.round(s.retirementAge)}. This is an illustration, not a recommendation or guarantee.`
      : `Under the entered assumptions, the current retirement contribution of ${contributionText(s.currentMonthlyInvestment, s.contributionFrequency)} is at or above the amount required by the model for the selected retirement age. This is an illustration, not a recommendation or guarantee.`;

    $('reportSavingsSources').innerHTML = [
      [`Current retirement savings`, formatINR(s.currentSavings)],
      [`Contributions added before retirement (nominal contributions)`, formatINR(model.extras.contributionPrincipal)],
      [`Modelled investment growth / (decline) by retirement`, formatINR(model.extras.modelledInvestmentGrowth)],
      [`Projected savings at retirement (future ${currencyCode()})`, formatINR(r.projectedCorpus)],
    ].map(([a,b], i, arr) => reportRow(a,b, i === arr.length - 1 ? 'report-total-value' : '')).join('');

    $('reportInflationImpact').innerHTML = [
      [`Retirement lifestyle in today's ${currencyCode()}`, `${formatINR(r.retirementLifestyleToday)}/mo`],
      [`Same lifestyle at age ${Math.round(s.retirementAge)} in future ${currencyCode()}`, `${formatINR(r.retirementLifestyleFuture)}/mo`],
      ['Nominal amount multiple', `${model.extras.inflationMultiple.toFixed(2)}×`],
    ].map(([a,b]) => reportRow(a,b)).join('');
    $('reportInflationNarrative').textContent = `Today's money shows comparable purchasing power. Future ${currencyCode()} shows the modelled nominal amount at age ${Math.round(s.retirementAge)} after applying the entered inflation assumptions.`;

    $('reportMethodologyLabel').textContent = `Methodology: ${model.methodology.label || 'Current methodology'}`;
    $('reportMethodologyUrl').textContent = (model.methodology.url || '').replace(/^https?:\/\//, '');

    const assumptions = model.assumptions.map(x => [x.label, x.value]);
    $('reportAssumptions').innerHTML = assumptions.map(([a,b]) => reportRow(a,b)).join('');

    $('reportBreakdown').innerHTML = [
      [`Recurring retirement expenses (value required at retirement)`, formatINR(r.recurringExpensePV)],
      [`Less retirement income (value at retirement)`, `−${formatINR(r.retirementIncomePV)}`],
      [`One-time retirement goals (value at retirement)`, formatINR(r.goalsPV)],
      [`Safety buffer (future ${currencyCode()} at retirement)`, formatINR(r.safetyBufferAmount)],
      [`Estimated retirement requirement (future ${currencyCode()} at retirement)`, formatINR(r.requiredCorpus)],
    ].map(([a,b], i, arr) => reportRow(a,b, i === arr.length - 1 ? 'report-total-value' : '')).join('');

    $('reportFunding').innerHTML = [
      [`Future value of existing savings at retirement (future ${currencyCode()})`, formatINR(r.futureExisting)],
      [`Future value of current contributions at retirement (future ${currencyCode()})`, formatINR(r.futureCurrentContrib)],
      [`Projected savings at retirement (future ${currencyCode()})`, formatINR(r.projectedCorpus)],
      [`Funding gap at retirement (future ${currencyCode()})`, r.gap > 0 ? formatINR(r.gap) : 'No gap under assumptions'],
      [requiredContributionLabelText(s.contributionFrequency, 'Total') + ' from now', contributionText(r.totalMonthlyNeeded, s.contributionFrequency)],
      [requiredContributionLabelText(s.contributionFrequency, 'Additional'), r.extraMonthlyNeeded > 1 ? contributionText(r.extraMonthlyNeeded, s.contributionFrequency) : `${zeroMoney()} under assumptions`],
      ['Modelled current-plan runway', r.projectedDepletionAge !== null && r.projectedDepletionAge < s.planningAge - 0.05 ? `Around ${formatAgeYearsMonths(Math.max(s.retirementAge, r.projectedDepletionAge), true)}` : `Through age ${Math.round(s.planningAge)}`],
    ].map(([a,b]) => reportRow(a,b)).join('');

    const changesBlock = $('reportExpenseChangesBlock');
    if (s.mode === 'detailed' && r.expenseChanges.length) {
      changesBlock.style.display = '';
      $('reportExpenseChangeFutureHead').textContent = `Projected at retirement (age ${Math.round(s.retirementAge)}, future ${currencyCode()})`;
      $('reportExpenseContext').textContent = `All listed expenses · retirement age ${Math.round(s.retirementAge)}`;
      $('reportExpenseChanges').innerHTML = r.expenseChanges.map(x => {
        const change = Math.abs(x.change) < 1 ? 'No lifestyle change' : x.change > 0 ? `+${formatINR(x.change)}` : `−${formatINR(Math.abs(x.change))}`;
        const todayToRetirement = `${formatINR(x.today)} → ${formatINR(x.retirement)}`;
        const ruleAndChange = `${expenseRuleSummary(x, s)} · ${change}`;
        return `<tr><td>${escapeXml(x.name)}</td><td>${escapeXml(todayToRetirement)}</td><td>${escapeXml(formatINR(x.retirementFuture))}</td><td>${escapeXml(ruleAndChange)}</td></tr>`;
      }).join('');
    } else {
      changesBlock.style.display = 'none';
      $('reportExpenseChanges').innerHTML = '';
      $('reportExpenseContext').textContent = 'Detailed planner required for expense-by-expense reporting';
    }

    $('reportScenarios').innerHTML = scenarioResults(s).map(({age, result}) => {
      const selected = age === Math.round(s.retirementAge);
      return `<tr class="${selected ? 'report-scenario-selected' : ''}">
        <td>${age}${selected ? ' (selected)' : ''}</td>
        <td>${escapeXml(formatINR(result.requiredCorpus))}</td>
        <td>${escapeXml(contributionText(result.totalMonthlyNeeded, s.contributionFrequency))}</td>
        <td>${Math.max(0, result.fundedPct).toFixed(0)}%</td>
      </tr>`;
    }).join('');
    const scenarioFundingNote = $('reportScenarioFundingNote');
    if (scenarioFundingNote) scenarioFundingNote.textContent = `Projected funding uses your current plan - ${formatINR(s.currentSavings)} already saved plus ${contributionText(s.currentMonthlyInvestment, s.contributionFrequency)} ongoing retirement contribution, together with the entered return assumptions. It does not assume the recurring contribution required shown in the previous column.`;

    const expenseStartPoint = r.expensePoints[0] || { age: s.currentAge, value: r.currentTodayExpense };
    const expenseEndPoint = r.expensePoints[r.expensePoints.length - 1] || { age: s.planningAge, value: r.retirementLifestyleFuture };
    const expenseRetirementPoint = r.expensePoints.find(p => Math.abs(p.age - s.retirementAge) < 0.01) || { age: s.retirementAge, value: r.retirementLifestyleFuture };
    const nearestExpensePoint = (age) => r.expensePoints.reduce((best, p) => Math.abs(p.age-age) < Math.abs(best.age-age) ? p : best, r.expensePoints[0]);
    const preMidAge = Math.max(s.currentAge, Math.min(s.retirementAge, Math.round(((s.currentAge + s.retirementAge) / 2) / 5) * 5));
    const postMidAge = Math.max(s.retirementAge, Math.min(s.planningAge, Math.round(((s.retirementAge + s.planningAge) / 2) / 5) * 5));
    const milestoneBase = [expenseStartPoint, nearestExpensePoint(preMidAge), expenseRetirementPoint, nearestExpensePoint(postMidAge), expenseEndPoint]
      .filter((p, i, arr) => arr.findIndex(q => Math.abs(q.age-p.age) < 0.01) === i);
    const expenseMilestones = milestoneBase.map((p, idx) => ({
      ...p,
      labelTitle: Math.abs(p.age-s.currentAge) < 0.01 ? `Age ${Math.round(p.age)} · today` : Math.abs(p.age-s.retirementAge) < 0.01 ? `Age ${Math.round(p.age)} · retirement` : Math.abs(p.age-s.planningAge) < 0.01 ? `Age ${Math.round(p.age)} · plan end` : `Age ${Math.round(p.age)}`,
      labelValue: `${formatINR(p.value, true)}/mo`,
      labelPlacement: 'above',
      // Keep neighbouring milestone callouts on the same natural side of the line.
      // The chart renderer flips the final/right-edge label automatically and enforces
      // a minimum gap between boxes so adjacent ages never visually merge.
      labelSide: idx === milestoneBase.length - 1 ? 'left' : 'right'
    }));
    const reportExpensePath = expenseMilestones.map(({age,value}) => ({age,value}));
    renderLineChart($('reportExpenseChart'), reportExpensePath, {
      retirementAge: s.retirementAge, valueFormatter: v => formatINR(v, true), yLabel: 'Monthly spending',
      axisTitle: `Monthly household spending`,
      primaryLabel: 'Monthly spending', interactive: false,
      labelPoints: expenseMilestones, areaFill: true
    });
    const expenseStats = $('reportExpenseChartStats');
    if (expenseStats) expenseStats.innerHTML = [
      [`Today · age ${formatAgeCompact(s.currentAge)}`, `${formatINR(expenseStartPoint.value, true)}/mo`],
      [`At retirement · age ${formatAgeCompact(s.retirementAge)}`, `${formatINR(expenseRetirementPoint.value, true)}/mo`],
      [`Plan end · age ${formatAgeCompact(s.planningAge)}`, `${formatINR(expenseEndPoint.value, true)}/mo`]
    ].map(([label, value]) => `<div class="report-chart-stat"><span>${escapeXml(label)}</span><strong>${escapeXml(value)}</strong></div>`).join('');
    const expenseNote = $('reportExpenseChartNote');
    if (expenseNote) expenseNote.textContent = `How to read this chart: age ${Math.round(s.currentAge)} is today, so ${formatINR(expenseStartPoint.value, true)}/mo is the current amount. Every later point is the modelled nominal future-${currencyCode()} amount at that age. At retirement age ${Math.round(s.retirementAge)}, the modelled monthly amount is about ${formatINR(expenseRetirementPoint.value, true)}/mo. Changes reflect the inflation, expense rules and lifestyle assumptions entered.`;
    const reportDepletionMarkers = r.projectedDepletionAge !== null && r.projectedDepletionAge < s.planningAge - 0.05
      ? [{ age: Math.max(s.retirementAge, r.projectedDepletionAge), value: 0, title: `Current plan reaches ${formatINR(0)}`, subtitle: `Around ${formatAgeCompact(Math.max(s.retirementAge, r.projectedDepletionAge))}`, color: '#b93838' }]
      : [];
    renderLineChart($('reportPortfolioChart'), r.portfolioPoints, {
      retirementAge: null, valueFormatter: v => formatINR(v, true), yLabel: '',
      axisTitle: `Portfolio balance (nominal ${currencyCode()})`,
      primaryLabel: 'Fully funded target path', compareLabel: 'Your current-plan path', comparePoints: r.currentPortfolioPoints, interactive: false,
      primaryColor: '#123f5f', compareColor: '#0e827a', verticalMarkers: reportDepletionMarkers, startPointLabels: true,
      showGapAtStart: true, shadeAfterMarker: reportDepletionMarkers.length > 0, endPointLabels: true
    });
    const portfolioStats = $('reportPortfolioChartStats');
    if (portfolioStats) portfolioStats.innerHTML = [
      ['Target at retirement', formatINR(r.requiredCorpus, true)],
      ['Your projected savings', formatINR(r.projectedCorpus, true)],
      [r.gap > 0 ? 'Funding gap' : 'Projected surplus', formatINR(Math.abs(r.gap), true)],
      ['Current-plan runway', r.projectedDepletionAge !== null && r.projectedDepletionAge < s.planningAge - 0.05 ? `Around ${formatAgeYearsMonths(Math.max(s.retirementAge, r.projectedDepletionAge), true)}` : `Through age ${Math.round(s.planningAge)}`]
    ].map(([label, value]) => `<div class="report-chart-stat"><span>${escapeXml(label)}</span><strong>${escapeXml(value)}</strong></div>`).join('');
    const reportPortfolioNote = $('reportPortfolioChartNote');
    const targetEndBalance = r.portfolioPoints.length ? r.portfolioPoints[r.portfolioPoints.length - 1].value : 0;
    if (reportPortfolioNote) reportPortfolioNote.textContent = `How to read this chart: the green current-plan path starts at retirement with projected savings of ${formatINR(r.projectedCorpus, true)}. The blue target-funded path assumes retirement starts with the full modelled requirement of ${formatINR(r.requiredCorpus, true)}, which includes the ${s.bufferRate.toFixed(0)}% safety buffer (${formatINR(r.safetyBufferAmount, true)}). The ${formatINR(Math.abs(r.gap), true)} difference at retirement is the modelled ${r.gap > 0 ? 'funding gap' : 'surplus'}.${reportDepletionMarkers.length ? ` The current-plan path reaches zero around ${formatAgeYearsMonths(reportDepletionMarkers[0].age, true)}.` : ` The current-plan path remains above zero through age ${Math.round(s.planningAge)}.`} Under the fully funded target path, ${formatINR(targetEndBalance, true)} remains at age ${Math.round(s.planningAge)} in this model because any unused reserve stays invested at the entered retirement return. This remaining balance is not an extra amount you must fund on top of the retirement requirement.`;
  }

  function bindDelegatedRows() {
    ['expenseRows','incomeRows','goalRows'].forEach(id => {
      $(id).addEventListener('input', calculateAndRender);
      $(id).addEventListener('change', (e) => {
        if (e.target.classList.contains('exp-rule')) {
          const tr = e.target.closest('tr');
          renderExpenseSetting(tr, e.target.value === 'end' ? value('retirementAge') - 5 : 100);
        }
        calculateAndRender();
      });
      $(id).addEventListener('click', e => {
        const btn = e.target.closest('.remove-row');
        if (!btn) return;
        btn.closest('tr').remove();
        calculateAndRender();
      });
    });
  }

  function serializePlan() {
    return buildState();
  }

  function applyPlan(data) {
    suppressCalculate = true;
    try {
      const scalarIds = [
        'currentAge','retirementAge','planningAge','currentSavings','currentMonthlyInvestment','preReturn','postReturn','bufferRate',
        'quickMonthlyExpense','quickRetirementPct','quickInflation','generalInflation','healthInflation','lifestyleInflation','educationInflation',
        'phase1Pct','phase2Pct','phase3Pct'
      ];
      scalarIds.forEach(id => { if (data[id] !== undefined && $(id)) $(id).value = data[id]; });
      if (data.payFrequency && $('payFrequency')) { $('payFrequency').value = data.payFrequency; payFrequencyUserOverride = true; }
      if (data.contributionFrequency && $('contributionFrequency')) { $('contributionFrequency').value = data.contributionFrequency; contributionFrequencyUserOverride = true; }
      if (data.sameAsPayCycle !== undefined && $('sameAsPayCycle')) $('sameAsPayCycle').checked = Boolean(data.sameAsPayCycle);
      syncFrequencyOptions();
      $('expenseRows').innerHTML = ''; (data.expenses || DEFAULT_EXPENSES).forEach(addExpenseRow);
      $('incomeRows').innerHTML = ''; (data.incomes || DEFAULT_INCOMES).forEach(addIncomeRow);
      $('goalRows').innerHTML = ''; (data.goals || DEFAULT_GOALS).forEach(addGoalRow);
      setMode(data.mode || 'quick', false);
    } finally {
      suppressCalculate = false;
      calculateAndRender();
    }
  }

  function setEmptyResultState(message = '') {
    lastResult = null;
    const dashIds = [
      'requiredCorpus','firstYearExpense','firstYearIncome','firstYearNet','projectedCorpus','corpusGap','totalMonthlyNeeded','extraMonthlyNeeded',
      'todayVsRetirement','todayVsFutureRetirement','monthlyReduced','monthlyIncreased','glanceTodaySpend','glanceRetirementSpend','glanceFutureSpend',
      'glanceReduced','glanceIncreased','breakdownExpensePV','breakdownIncomePV','breakdownGoalsPV','breakdownBuffer','breakdownTotal',
      'insightLifestyle','insightRunway','insightContribution','insightExpense'
    ];
    dashIds.forEach(id => { if ($(id)) $(id).textContent = '—'; });
    if ($('yearsToRetire')) $('yearsToRetire').textContent = Math.max(0, value('retirementAge') - value('currentAge')).toFixed(0);
    if ($('resultPlanningAge')) $('resultPlanningAge').textContent = value('planningAge', 90).toFixed(0);
    if ($('fundedPercent')) $('fundedPercent').textContent = '—';
    if ($('progressFill')) $('progressFill').style.width = '0%';
    if ($('fundingMessage')) $('fundingMessage').textContent = message || 'Enter monetary amounts to calculate your retirement plan.';
    if ($('fundingStatus')) $('fundingStatus').textContent = 'Waiting for amounts';
    if ($('fundingStatusNote')) $('fundingStatusNote').textContent = 'Enter your savings, contributions and retirement spending assumptions to build the estimate.';
    if ($('budgetNarrative')) $('budgetNarrative').textContent = '';
    if ($('quickTodayRetirementBudget')) $('quickTodayRetirementBudget').textContent = `${zeroMoney()}/mo`;
    if ($('detailedExpenseTotal')) $('detailedExpenseTotal').textContent = zeroMoney();
    if ($('expenseChangeList')) $('expenseChangeList').innerHTML = '<div class="chart-empty">Enter your monetary amounts to see the retirement expense breakdown.</div>';
    if ($('expenseChart')) $('expenseChart').innerHTML = '<div class="chart-empty">Enter your monetary amounts to draw the household expense timeline.</div>';
    if ($('portfolioChart')) $('portfolioChart').innerHTML = '<div class="chart-empty">Enter your monetary amounts to draw the retirement portfolio paths.</div>';
    if ($('scenarioGrid')) $('scenarioGrid').innerHTML = '<div class="chart-empty">Enter your monetary amounts to compare retirement ages.</div>';
    if ($('scenarioTakeaway')) $('scenarioTakeaway').innerHTML = '';
    ['insightLifestyleNote','insightRunwayNote','insightContributionNote','insightExpenseNote'].forEach(id => {
      if ($(id)) $(id).textContent = 'Available after you enter monetary amounts.';
    });
    if ($('copyBtn')) $('copyBtn').disabled = true;
    if ($('printBtn')) $('printBtn').disabled = true;
  }

  function clearMonetaryAmounts() {
    suppressCalculate = true;
    try {
      ['currentSavings','currentMonthlyInvestment','quickMonthlyExpense'].forEach(id => { if ($(id)) $(id).value = '0'; });
      qsa('.exp-amount', $('expenseRows')).forEach(el => { el.value = '0'; });
      qsa('.inc-amount', $('incomeRows')).forEach(el => { el.value = '0'; });
      qsa('.goal-amount', $('goalRows')).forEach(el => { el.value = '0'; });
    } finally {
      suppressCalculate = false;
    }
  }

  function clearMoneyForCountryChange() {
    clearMonetaryAmounts();
    $('copyStatus').textContent = '';
    $('saveStatus').textContent = `Country changed to ${regionLabel()}. Monetary amounts were cleared so values from the previous country are not reinterpreted as ${currencyCode()}.`;
    calculateAndRender();
  }

  function resetPlan() {
    const currentMode = mode;
    payFrequencyUserOverride = false;
    contributionFrequencyUserOverride = false;
    if ($('sameAsPayCycle')) $('sameAsPayCycle').checked = false;
    syncFrequencyOptions();
    const indiaDemo = (!L || (L.getRegion() === 'IN' && L.getCurrency() === 'INR'));
    const defaults = indiaDemo
      ? { ...DEFAULTS, mode: currentMode }
      : { ...DEFAULTS, mode: currentMode, currentSavings: 0, currentMonthlyInvestment: 0, quickMonthlyExpense: 0 };
    const expenses = indiaDemo ? DEFAULT_EXPENSES.map(x => ({ ...x })) : DEFAULT_EXPENSES.map(x => ({ ...x, amount: 0 }));
    const incomes = indiaDemo ? DEFAULT_INCOMES.map(x => ({ ...x })) : DEFAULT_INCOMES.map(x => ({ ...x, amount: 0 }));
    applyPlan({ ...defaults, expenses, incomes, goals: [] });
    $('copyStatus').textContent = '';
    $('saveStatus').textContent = indiaDemo
      ? 'Plan reset to the default Carrowmont example values.'
      : `Plan reset to the default assumptions. Monetary fields are zero for ${currencyCode()} so you can enter your own amounts.`;
  }

  async function copyTextToClipboard(text) {
    if (navigator.clipboard && window.isSecureContext) {
      try { await navigator.clipboard.writeText(text); return true; } catch (_) { /* fall through */ }
    }
    try {
      const area = document.createElement('textarea');
      area.value = text;
      area.setAttribute('readonly','');
      area.style.position = 'fixed';
      area.style.opacity = '0';
      document.body.appendChild(area);
      area.select();
      const ok = document.execCommand('copy');
      area.remove();
      return ok;
    } catch (_) { return false; }
  }

  function preparePrintReport() {
    if (!lastResult) return;
    buildPrintReport(lastResult);
  }

  function bindEvents() {
    $('quickModeBtn').addEventListener('click', () => setMode('quick'));
    $('detailedModeBtn').addEventListener('click', () => setMode('detailed'));
    $('resetBtn').addEventListener('click', resetPlan);
    $('addExpenseBtn').addEventListener('click', () => { addExpenseRow(); calculateAndRender(); });
    $('addIncomeBtn').addEventListener('click', () => { addIncomeRow(); calculateAndRender(); });
    $('addGoalBtn').addEventListener('click', () => { addGoalRow(); calculateAndRender(); });
    $('scenarioGrid').addEventListener('click', (e) => {
      const btn = e.target.closest('.scenario-use-button');
      if (!btn) return;
      $('retirementAge').value = btn.dataset.retirementAge;
      calculateAndRender();
      $('results').scrollIntoView({ behavior: 'smooth', block: 'start' });
    });

    $('payFrequency')?.addEventListener('change', () => { payFrequencyUserOverride = true; if ($('sameAsPayCycle')?.checked) $('contributionFrequency').value = $('payFrequency').value; updateFrequencyCopy(); calculateAndRender(); });
    $('contributionFrequency')?.addEventListener('change', () => { contributionFrequencyUserOverride = true; updateFrequencyCopy(); calculateAndRender(); });
    $('sameAsPayCycle')?.addEventListener('change', () => { if ($('sameAsPayCycle').checked) { contributionFrequencyUserOverride = false; $('contributionFrequency').value = $('payFrequency').value; } else { contributionFrequencyUserOverride = true; } $('contributionFrequency').disabled = $('sameAsPayCycle').checked; updateFrequencyCopy(); calculateAndRender(); });

    qsa('input', $('planner')).forEach(input => {
      if (!input.closest('tbody')) {
        input.addEventListener('input', calculateAndRender);
        input.addEventListener('change', calculateAndRender);
      }
    });

    $('copyBtn').addEventListener('click', async () => {
      if (!lastResult) return;
      const r = lastResult;
      const model = buildRetirementReportModel(r);
      const funded = Math.max(0, r.fundedPct).toFixed(0);
      const gapText = r.gap > 0 ? formatINR(r.gap) : 'No gap under assumptions';
      const extraText = r.extraMonthlyNeeded > 1 ? formatINR(r.extraMonthlyNeeded) : `${zeroMoney()} under assumptions`;
      const text = [
        'CARROWMONT RETIREMENT PLAN SUMMARY',
        '',
        `Country / region: ${regionLabel()}`,
        `Currency: ${currencyCode()}`,
        `Planner mode: ${r.s.mode === 'detailed' ? 'Detailed planner' : 'Quick estimate'}`,
        `Pay frequency: ${frequencyLabel(r.s.payFrequency)}`,
        `Retirement contribution frequency: ${frequencyLabel(r.s.contributionFrequency)}`,
        `${currentContributionLabelText(r.s.contributionFrequency)}: ${contributionText(r.s.currentMonthlyInvestment, r.s.contributionFrequency)}`,
        `Retirement age: ${Math.round(r.s.retirementAge)}`,
        `Plan through age: ${Math.round(r.s.planningAge)}`,
        '',
        `Estimated retirement requirement (future ${currencyCode()} at retirement): ${formatINR(r.requiredCorpus)}`,
        `Projected retirement savings (future ${currencyCode()} at retirement): ${formatINR(r.projectedCorpus)}`,
        `Funding gap at retirement (future ${currencyCode()}): ${gapText}`,
        `Projected funding: ${funded}%`,
        `${requiredContributionLabelText(r.s.contributionFrequency, 'Total')} from now: ${contributionText(r.totalMonthlyNeeded, r.s.contributionFrequency)}`,
        `${requiredContributionLabelText(r.s.contributionFrequency, 'Additional')} vs current plan: ${r.extraMonthlyNeeded > 1 ? contributionText(r.extraMonthlyNeeded, r.s.contributionFrequency) : `${zeroMoney()} under assumptions`}`,
        `Modelled current-plan runway: ${r.projectedDepletionAge !== null && r.projectedDepletionAge < r.s.planningAge - 0.05 ? `around ${formatAgeYearsMonths(Math.max(r.s.retirementAge, r.projectedDepletionAge), true)}` : `through age ${Math.round(r.s.planningAge)}`}`,
        '',
        `Today's monthly spending (current ${currencyCode()}): ${formatINR(r.currentTodayExpense)}/mo`,
        `Retirement lifestyle (today's ${currencyCode()}): ${formatINR(r.retirementLifestyleToday)}/mo`,
        `Projected monthly spending at retirement (age ${Math.round(r.s.retirementAge)}, future ${currencyCode()}): ${formatINR(r.retirementLifestyleFuture)}/mo`,
        '',
        `Methodology: ${model.methodology.label || 'Current methodology'}`,
        `Generated: ${model.generatedDisplay || model.generatedDate || ''}`,
        '',
        'Educational planning estimate only. Results depend on the assumptions entered and actual outcomes may differ.',
        'carrowmont.com'
      ].join('\n');
      const copied = await copyTextToClipboard(text);
      $('copyStatus').textContent = copied ? 'Carrowmont Summary copied.' : 'Copy is unavailable in this browser. Select the summary manually instead.';
    });

    $('printBtn').addEventListener('click', async () => {
      if (!lastResult) return;
      const status = $('reportStatus');
      if (!window.CarrowmontPdfExport || !window.CarrowmontRetirementPdfRenderer) {
        if (status) status.textContent = 'The report could not be generated. Please refresh the page and try again.';
        return;
      }
      preparePrintReport();
      const btn = $('printBtn');
      btn.disabled = true;
      btn.setAttribute('aria-busy','true');
      if (status) status.textContent = 'Preparing your report...';
      try {
        const canvases = await window.CarrowmontRetirementPdfRenderer.render($('printReport'));
        const reportModel = window.__CARROWMONT_LAST_REPORT_MODEL || buildRetirementReportModel(lastResult);
        const base = REPORT_ENGINE
          ? REPORT_ENGINE.filename('retirement-planning-report', reportModel.generatedAt || new Date())
          : `retirement-planning-report-${reportModel.generatedDate || ''}`;
        await window.CarrowmontPdfExport.downloadCanvases(canvases,{filename:`${base}.pdf`,quality:.95});
        if (status) status.textContent = 'Report has been downloaded.';
      } catch (err) {
        console.error('Retirement report PDF generation failed', err);
        if (status) status.textContent = 'The report could not be generated. Please refresh the page and try again.';
      } finally {
        btn.disabled = false;
        btn.removeAttribute('aria-busy');
      }
    });

  }

  function init() {
    DEFAULT_EXPENSES.forEach(addExpenseRow);
    DEFAULT_INCOMES.forEach(addIncomeRow);
    DEFAULT_GOALS.forEach(addGoalRow);
    applyFirstLoadMoneyDefaults();
    bindDelegatedRows();
    bindEvents();
    setMode(DEFAULTS.mode, false);
    syncLocaleLabels();
    syncFrequencyOptions();
    const legacyYear = $('year'); if (legacyYear) legacyYear.textContent = new Date().getFullYear();
    window.addEventListener('beforeprint', preparePrintReport);
    window.addEventListener('carrowmont:localechange', () => {
      const nextRegion = L ? L.getRegion() : 'IN';
      const countryChanged = nextRegion !== activeLocaleRegion;
      activeLocaleRegion = nextRegion;
      syncLocaleLabels();
      if (countryChanged) { payFrequencyUserOverride = false; contributionFrequencyUserOverride = false; }
      syncFrequencyOptions();
      if (countryChanged) clearMoneyForCountryChange();
      else calculateAndRender();
    });
    calculateAndRender();
  }

  init();
})();
