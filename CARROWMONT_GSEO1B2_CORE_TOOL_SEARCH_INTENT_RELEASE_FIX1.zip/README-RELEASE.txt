CARROWMONT GSEO1B-2 — CORE TOOL SEARCH INTENT ALIGNMENT

Baseline: Source Snapshot 53
Expected PRs: 6

Approved scope:
- financial-independence: index.html metadata/search identity only
- retirement-calculator: planner.html metadata/search identity only; root landing page remains distinct
- budget-cash-flow-planner: index.html metadata/search identity only
- inflation-calculator: index.html metadata/search identity only
- draw004.github.io: GSEO1B-2 spec + sitemap lastmods for the four changed URLs
- carrowmont-qa: source-contract + smoke protection

No calculator math, visible H1/product label, report, localization, URL, layout or workflow changes.

Merge order:
1. financial-independence
2. retirement-calculator
3. budget-cash-flow-planner
4. inflation-calculator
5. draw004.github.io
6. carrowmont-qa LAST

After merge: Pages -> Automated QA -> Multi-Repo Guard -> fresh Source Snapshot -> IndexNow -> Google URL Inspection for the four changed calculator URLs.

Staging rule: upload this ZIP only to a disposable branch from main. Do not merge the staging branch itself.

FIX1 note:
- Production files are identical to V1.
- Browser QA failure root cause was a broad page.locator('h1') selector on Inflation Calculator. Inflation pre-renders a hidden print-report H1, so Playwright strict mode saw two H1 elements.
- FIX1 scopes the four visible product-heading assertions to main h1. This is QA-only; no calculator/UI/search metadata changes beyond V1.
