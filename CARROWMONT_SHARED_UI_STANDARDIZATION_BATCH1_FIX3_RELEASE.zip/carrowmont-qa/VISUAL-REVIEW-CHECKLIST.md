# Carrowmont visual review checklist

Automated tests catch calculation regressions, JavaScript errors, chart population, missing axis labels, broken links, overflow and report-download failures. A short human review should still be performed before a release.

## Desktop Chrome and Edge

- No heading, button, legend, chart label or value is clipped.
- Country/currency control is aligned and consistent.
- "Back to all Carrowmont tools" appears consistently.
- Result cards line up and long currency values do not escape their cards.
- Report buttons stay fully inside their result/action boxes.
- Chart legends, axes and permanent values remain readable without hover.
- Homepage investment-tool naming follows the country rule: India uses SIP Calculator; international views use Recurring Investment Calculator.
- Homepage "Want to build 1 Crore?" section begins close enough to the first viewport to be discoverable for India/INR.

## Mobile

- No horizontal scroll.
- Buttons stack cleanly and remain tap-friendly.
- Charts remain legible rather than compressed into unreadable labels.
- Navigation and locale selector do not overlap.

## Shared UI shell

- Budget header matches the established Carrowmont tool header width, navy wordmark, product-label hierarchy, navigation scale and spacing.
- Country/currency control uses the same rounded pill treatment across tools.
- Budget open locale popover matches the canonical tool width, spacing, styled selects, note treatment and Done button.
- Mobile locale popover remains fully inside the viewport with no horizontal overflow.
- All active tool footers expose the same six-tool registry plus All tools.
- Footer navigation contains no directional arrows; dedicated CTA cards may retain intentional arrows.
- Currency options use the shared `CODE · Currency Name` format.

## PDFs - shared Carrowmont report standard

- All pages have consistent margins, typography and visual hierarchy.
- No clipped chart labels, values, table rows or methodology text.
- Every report contains a separate **Report Guide & Methodology** page.
- The guide page contains **How to read this report**, report-specific methodology, report-specific terminology, important assumptions/disclaimer, methodology details and `contact@carrowmont.com`.
- Every report contains a separate **Continue planning with Carrowmont** page.
- The investment-tool card is country-aware: **SIP Calculator** for India and **Recurring Investment Calculator** outside India.
- "Monthly Investment Calculator" is not used as the product identity outside the Learn content that has been intentionally deferred for a later SEO/content pass.
- Charts make sense on paper without hover.
- Financial Independence PDF charts show permanent printed values at the selected age.
- Retirement report key-value rows expand for wrapped labels; text does not touch divider lines or neighboring rows.
- SIP / Recurring Investment methodology rows wrap cleanly for long cadence wording such as Fortnightly / Every 2 Weeks.
- Final guide/tools pages are not awkwardly split or crowded.
- Download confirmation reads exactly: "Report has been downloaded."

A release is ready when automated QA is green and this checklist has no material visual defects.

## Final report polish checks - September 2026
- SIP / Recurring Investment growth visuals: final year prints both projected and invested values; annual-increase comparison prints both projected step-up and fixed-contribution values.
- SIP / Recurring Investment callouts: projected / step-up labels sit above their series and invested / fixed labels sit below their series at the midpoint and final year.
- Financial Independence money-added chart: projected portfolio callout is above the portfolio series and money-added callout is below the assets + contributions series.
- Report Guide & Methodology: How to read card uses compact content-aware height and stronger guidance text without changing the disclaimer layout.
- Retirement: previously fixed wrapping/pagination remains visually clean; no regression.

## Shared UI / Budget report additions - 2026-10-02
- Verify the closed country/currency pill is the same height across all six tools (44px desktop; 38px mobile) and remains a true pill.
- Verify the Budget & Cash Flow Planner country/currency popover visually matches the established tool shell.
- In the Budget & Cash Flow Report, inspect page 3: the "How this report interprets your entries" rows must wrap cleanly with no label/body overlap or clipped wording.

