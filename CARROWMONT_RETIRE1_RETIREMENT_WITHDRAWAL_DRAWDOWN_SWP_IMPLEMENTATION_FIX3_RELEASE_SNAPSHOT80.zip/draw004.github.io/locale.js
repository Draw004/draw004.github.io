(function () {
  "use strict";

  const STORAGE_REGION = "carrowmont_region_v1";
  const STORAGE_CURRENCY = "carrowmont_currency_v1";

  const regions = {
    IN: { label: "India", locale: "en-IN", currency: "INR" },
    US: { label: "United States", locale: "en-US", currency: "USD" },
    CA: { label: "Canada", locale: "en-CA", currency: "CAD" },
    GB: { label: "United Kingdom", locale: "en-GB", currency: "GBP" },
    AU: { label: "Australia", locale: "en-AU", currency: "AUD" },
    AT: { label: "Austria", locale: "de-AT", currency: "EUR" },
    BD: { label: "Bangladesh", locale: "en-BD", currency: "BDT" },
    BE: { label: "Belgium", locale: "nl-BE", currency: "EUR" },
    NZ: { label: "New Zealand", locale: "en-NZ", currency: "NZD" },

    CL: { label: "Chile", locale: "es-CL", currency: "CLP" },
    DK: { label: "Denmark", locale: "da-DK", currency: "DKK" },
    CN: { label: "China", locale: "zh-CN", currency: "CNY" },
    JP: { label: "Japan", locale: "ja-JP", currency: "JPY" },
    KR: { label: "South Korea", locale: "ko-KR", currency: "KRW" },
    SG: { label: "Singapore", locale: "en-SG", currency: "SGD" },
    AE: { label: "United Arab Emirates", locale: "en-AE", currency: "AED" },
    SA: { label: "Saudi Arabia", locale: "ar-SA", currency: "SAR" },
    OM: { label: "Oman", locale: "en-OM", currency: "OMR" },
    QA: { label: "Qatar", locale: "en-QA", currency: "QAR" },

    DE: { label: "Germany", locale: "de-DE", currency: "EUR" },
    FR: { label: "France", locale: "fr-FR", currency: "EUR" },
    IT: { label: "Italy", locale: "it-IT", currency: "EUR" },
    ES: { label: "Spain", locale: "es-ES", currency: "EUR" },
    FI: { label: "Finland", locale: "fi-FI", currency: "EUR" },
    IE: { label: "Ireland", locale: "en-IE", currency: "EUR" },
    NL: { label: "Netherlands", locale: "nl-NL", currency: "EUR" },
    NO: { label: "Norway", locale: "nb-NO", currency: "NOK" },
    PL: { label: "Poland", locale: "pl-PL", currency: "PLN" },
    PT: { label: "Portugal", locale: "pt-PT", currency: "EUR" },
    SE: { label: "Sweden", locale: "sv-SE", currency: "SEK" },
    CH: { label: "Switzerland", locale: "de-CH", currency: "CHF" },

    BR: { label: "Brazil", locale: "pt-BR", currency: "BRL" },
    MX: { label: "Mexico", locale: "es-MX", currency: "MXN" },
    ZA: { label: "South Africa", locale: "en-ZA", currency: "ZAR" },
    ID: { label: "Indonesia", locale: "id-ID", currency: "IDR" },
    MY: { label: "Malaysia", locale: "en-MY", currency: "MYR" },
    TH: { label: "Thailand", locale: "th-TH", currency: "THB" },
    PH: { label: "Philippines", locale: "en-PH", currency: "PHP" },
    VN: { label: "Vietnam", locale: "vi-VN", currency: "VND" },
    HK: { label: "Hong Kong", locale: "zh-HK", currency: "HKD" },
    TW: { label: "Taiwan", locale: "zh-TW", currency: "TWD" },
    RU: { label: "Russia", locale: "ru-RU", currency: "RUB" },
    TR: { label: "Türkiye", locale: "tr-TR", currency: "TRY" },

    OTHER: { label: "Other / International", locale: "en-US", currency: "USD" }
  };

  const currencies = {
    INR: { label: "Indian Rupee", symbol: "₹" },
    USD: { label: "US Dollar", symbol: "$" },
    CAD: { label: "Canadian Dollar", symbol: "C$" },
    GBP: { label: "British Pound", symbol: "£" },
    AUD: { label: "Australian Dollar", symbol: "A$" },
    NZD: { label: "New Zealand Dollar", symbol: "NZ$" },
    BDT: { label: "Bangladeshi Taka", symbol: "৳", currencyDisplay: "narrowSymbol" },
    CLP: { label: "Chilean Peso", symbol: "$" },
    DKK: { label: "Danish Krone", symbol: "kr" },
    EUR: { label: "Euro", symbol: "€" },
    CNY: { label: "Chinese Yuan", symbol: "CN¥" },
    JPY: { label: "Japanese Yen", symbol: "¥" },
    KRW: { label: "South Korean Won", symbol: "₩" },
    SGD: { label: "Singapore Dollar", symbol: "S$" },
    AED: { label: "UAE Dirham", symbol: "AED" },
    SAR: { label: "Saudi Riyal", symbol: "SAR" },
    OMR: { label: "Omani Rial", symbol: "OMR" },
    QAR: { label: "Qatari Riyal", symbol: "QAR" },
    CHF: { label: "Swiss Franc", symbol: "CHF" },
    NOK: { label: "Norwegian Krone", symbol: "kr" },
    PLN: { label: "Polish Zloty", symbol: "zł" },
    SEK: { label: "Swedish Krona", symbol: "kr" },
    BRL: { label: "Brazilian Real", symbol: "R$" },
    MXN: { label: "Mexican Peso", symbol: "MX$" },
    ZAR: { label: "South African Rand", symbol: "R" },
    IDR: { label: "Indonesian Rupiah", symbol: "Rp" },
    MYR: { label: "Malaysian Ringgit", symbol: "RM" },
    THB: { label: "Thai Baht", symbol: "฿" },
    PHP: { label: "Philippine Peso", symbol: "₱" },
    VND: { label: "Vietnamese Dong", symbol: "₫" },
    HKD: { label: "Hong Kong Dollar", symbol: "HK$" },
    TWD: { label: "New Taiwan Dollar", symbol: "NT$" },
    RUB: { label: "Russian Ruble", symbol: "₽" },
    TRY: { label: "Turkish Lira", symbol: "₺" }
  };

  function detectRegion() {
    const langs = (navigator.languages && navigator.languages.length ? navigator.languages : [navigator.language || "en-US"]).map(String);
    for (const lang of langs) {
      const upper = lang.toUpperCase().replace("_", "-");
      const parts = upper.split("-");
      const country = parts.length > 1 ? parts[parts.length - 1] : "";
      if (country === "UK") return "GB";
      if (regions[country]) return country;
    }
    return "OTHER";
  }
  function safeGet(key) { try { return localStorage.getItem(key); } catch (_) { return null; } }
  function safeSet(key, value) { try { localStorage.setItem(key, value); } catch (_) {} }

  let regionCode = safeGet(STORAGE_REGION);
  if (!regions[regionCode]) regionCode = detectRegion();
  let currencyCode = safeGet(STORAGE_CURRENCY);
  if (!currencies[currencyCode]) currencyCode = regions[regionCode].currency;

  function getRegion() { return regionCode; }
  function getCurrency() { return currencyCode; }
  function getProfile() { return regions[regionCode] || regions.OTHER; }
  function getLocale() { return getProfile().locale; }

  function emitChange() {
    window.dispatchEvent(new CustomEvent("carrowmont:localechange", { detail: { region: regionCode, currency: currencyCode } }));
  }
  function setRegion(code, opts = {}) {
    if (!regions[code]) return;
    regionCode = code;
    safeSet(STORAGE_REGION, regionCode);
    if (opts.syncCurrency !== false) {
      currencyCode = regions[code].currency;
      safeSet(STORAGE_CURRENCY, currencyCode);
    }
    emitChange();
  }
  function setCurrency(code) {
    if (!currencies[code]) return;
    currencyCode = code;
    safeSet(STORAGE_CURRENCY, currencyCode);
    emitChange();
  }
  function setLocale(region, currency) {
    if (!regions[region]) return;
    regionCode = region;
    currencyCode = currencies[currency] ? currency : regions[region].currency;
    safeSet(STORAGE_REGION, regionCode);
    safeSet(STORAGE_CURRENCY, currencyCode);
    emitChange();
  }

  function formatMoney(value, options = {}) {
    const n = Number(value) || 0;
    const currency = options.currency || currencyCode;
    const locale = options.locale || getLocale();
    const maximumFractionDigits = options.maximumFractionDigits ?? 0;
    try {
      return new Intl.NumberFormat(locale, {
        style: "currency",
        currency,
        maximumFractionDigits,
        minimumFractionDigits: options.minimumFractionDigits ?? 0
      }).format(n);
    } catch (_) {
      return `${currencies[currency]?.symbol || currency} ${Math.round(n).toLocaleString(locale)}`;
    }
  }

  function formatCompactMoney(value, options = {}) {
    const n = Number(value) || 0;
    const currency = options.currency || currencyCode;
    const locale = options.locale || getLocale();
    try {
      let formatted = new Intl.NumberFormat(locale, {
        style: "currency",
        currency,
        notation: "compact",
        compactDisplay: "short",
        maximumFractionDigits: options.maximumFractionDigits ?? 2,
        minimumFractionDigits: options.minimumFractionDigits ?? 0
      }).format(n);
      if (currency === "INR") formatted = formatted.replace(/(\d)(?=(?:Cr|L|K)\b)/g, "$1 ");
      return formatted;
    } catch (_) {
      return formatMoney(n, { currency, locale });
    }
  }

  function formatNumber(value, options = {}) {
    const n = Number(value) || 0;
    return new Intl.NumberFormat(options.locale || getLocale(), {
      maximumFractionDigits: options.maximumFractionDigits ?? 0
    }).format(n);
  }

  function currencySymbol(code = currencyCode) {
    return currencies[code]?.symbol || code;
  }

  function getMortgageTerms(region = regionCode) {
    const homeLoanMarket = ['IN', 'AU', 'NZ'].includes(region);
    const mortgageMarket = ['US', 'CA', 'GB', 'IE'].includes(region);
    const ukStyle = ['GB', 'IE'].includes(region);
    const noun = homeLoanMarket ? 'home loan' : mortgageMarket ? 'mortgage' : 'mortgage / home loan';
    const nounCap = homeLoanMarket ? 'Home loan' : mortgageMarket ? 'Mortgage' : 'Mortgage / home loan';
    const familyName = homeLoanMarket ? 'Home Loan Decision Centre' : mortgageMarket ? 'Mortgage Decision Centre' : 'Mortgage / Home Loan Decision Centre';
    const learnCategory = homeLoanMarket ? 'Home Loans' : mortgageMarket ? 'Mortgages' : 'Home Loans & Mortgages';
    const learnGuides = homeLoanMarket ? 'Home Loan guides' : mortgageMarket ? 'Mortgage guides' : 'Home Loan & Mortgage guides';
    const paymentLabel = region === 'IN' ? 'home loan EMI / payment' : homeLoanMarket ? 'home loan repayment' : mortgageMarket ? 'mortgage payment' : 'mortgage / home loan payment';
    const prepayLabel = region === 'IN' ? 'home loan prepayment' : ['AU','NZ'].includes(region) ? 'extra home loan repayments' : ukStyle ? 'mortgage overpayment' : mortgageMarket ? 'mortgage prepayment' : 'mortgage / home loan prepayment';
    const refinanceLabel = region === 'IN' ? 'home loan balance transfer' : ukStyle ? 'remortgaging or switching a mortgage deal' : ['AU','NZ'].includes(region) ? 'refinancing a home loan' : mortgageMarket ? 'mortgage refinancing' : 'refinancing or a balance transfer';
    const payoffLabel = homeLoanMarket ? 'Home Loan Payoff / Prepayment' : mortgageMarket ? 'Mortgage Payoff / Prepayment' : 'Mortgage / Home Loan Payoff';
    return {
      homeLoanMarket, mortgageMarket, ukStyle, noun, nounCap, familyName, learnCategory, learnGuides, paymentLabel, prepayLabel, refinanceLabel, payoffLabel,
      learnHubCta: `Open ${familyName} →`,
      learnPrepayTitle: `${prepayLabel.charAt(0).toUpperCase()+prepayLabel.slice(1)} vs investing: how should the trade-off be compared?`,
      learnRefiTitle: `When does ${refinanceLabel} break even?`,
      learnStressTitle: `How much could your ${paymentLabel} rise if rates increase?`,
      learnOneExtraTitle: `One extra ${homeLoanMarket ? 'home loan' : mortgageMarket ? 'mortgage' : 'mortgage / home loan'} payment a year: what could it save?`,
      learnEarlyExtraTitle: `Why can earlier extra ${homeLoanMarket ? 'home loan' : mortgageMarket ? 'mortgage' : 'loan'} payments save more?`,
      learnFiveYearsTitle: `How much extra could clear a ${noun} five years earlier?`,
      learnRentBuyDesc: `Compare the full financial trade-offs instead of only rent versus a ${paymentLabel}.`
    };
  }

  window.CarrowmontLocale = {
    regions, currencies,
    getRegion,
    getCurrency,
    getProfile,
    getLocale,
    setRegion, setCurrency, setLocale,
    formatMoney,
    formatCompactMoney,
    formatNumber,
    currencySymbol,
    getMortgageTerms
  };
})();
/* Carrowmont compact footer gateways - RETIRE1 */
(() => {
  'use strict';
  const L = window.CarrowmontLocale;
  if (!L) return;
  function housingLabel(region) {
    if (region === 'IN' || region === 'AU' || region === 'NZ') return 'Home Loan';
    if (region === 'US' || region === 'CA' || region === 'GB' || region === 'IE') return 'Mortgage';
    return 'Mortgage & Home Loan';
  }
  function syncCompactFooter() {
    const region = L.getRegion?.() || 'OTHER';
    const investment = region === 'IN' ? 'SIP Calculator' : 'Recurring Investment Calculator';
    document.querySelectorAll('.site-footer .footer-col').forEach(col => {
      const heading = col.querySelector(':scope > strong');
      if (!heading || heading.textContent.trim() !== 'Tools') return;
      col.dataset.cmCompactTools = '1';
      col.replaceChildren(heading);
      const links = [
        ['/tools.html','All financial tools','footer-all-tools'],
        ['/sip-calculator/',investment,'footer-investment-link'],
        ['/retirement-calculator/','Retirement Planner','footer-retirement-link'],
        ['/mortgage-payoff-calculator/',housingLabel(region),'footer-housing-gateway'],
        ['/budget-cash-flow-planner/','Budget & Cash Flow Planner','footer-budget-link']
      ];
      links.forEach(([href,label,className]) => {
        const a=document.createElement('a');a.href=href;a.textContent=label;a.className=className;
        col.appendChild(a);
      });
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', syncCompactFooter, { once:true });
  else syncCompactFooter();
  window.addEventListener('carrowmont:localechange', syncCompactFooter);
  window.CarrowmontCompactFooter = { sync: syncCompactFooter };
})();

