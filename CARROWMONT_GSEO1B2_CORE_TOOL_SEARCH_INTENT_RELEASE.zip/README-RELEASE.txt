CARROWMONT GSEO1B-2 — CORE TOOL SEARCH INTENT ALIGNMENT

Baseline: Source Snapshot 53
Expected PRs: 6

Approved scope:
- financial-independence: index.html metadata/search identity only
- retirement-calculator: planner.html metadata/search identity only; root landing page remains distinct
- budget-cash-flow-planner: index.html metadata/search identity only
- inflation-calculator: index.html metadata/search identity only
- draw004.github.io: GSEO1B-2 spec + sitemap lastmods for the four changed URLs
- carrowmont-qa: source-contract + smoke protection

No calculator math, visible H1/product label, report, localization, URL, layout or workflow changes.

Merge order:
1. financial-independence
2. retirement-calculator
3. budget-cash-flow-planner
4. inflation-calculator
5. draw004.github.io
6. carrowmont-qa LAST

After merge: Pages -> Automated QA -> Multi-Repo Guard -> fresh Source Snapshot -> IndexNow -> Google URL Inspection for the four changed calculator URLs.

Staging rule: upload this ZIP only to a disposable branch from main. Do not merge the staging branch itself.
