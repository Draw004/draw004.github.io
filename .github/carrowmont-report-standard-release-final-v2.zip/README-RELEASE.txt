Carrowmont report-standard release bundle

This ZIP is intended for the Carrowmont Batch PR Publisher.
Do not manually copy these files to main branches.

Safety model:
- reviewed base hashes are verified before changes are staged
- changed JavaScript is syntax-checked
- the multi-repo source contract runs against the staged tree
- staged Chrome browser/PDF QA runs before pull requests are created
- only manifest-listed paths may change
- the publisher creates review branches and PRs only
- the publisher never merges

After PR review/merge, run the live Carrowmont Automated QA and Multi-Repo Guard.
