Carrowmont final report visual-polish release bundle

This ZIP is intended for the existing Carrowmont Batch PR Publisher.
Do not manually copy these files to main branches.

Scope:
- FI PDF: projected portfolio callout above; money-added callout below.
- SIP / Recurring Investment charts: midpoint and final callouts aligned with their own series.
- SIP / Recurring Investment charts: final-year invested/fixed values are printed.
- Final projected labels explicitly say projected.
- Shared Report Guide: How to read panel uses content-aware compact height and stronger guidance text.
- QA: source contract and browser chart checks cover the polish.

Safety:
- Base hashes are from the post-merge source snapshot generated 2026-09-25T10:43:29Z.
- The existing publisher verifies hashes, syntax, source contracts, browser/PDF QA, and the change allow-list before it creates PRs.
- The publisher never merges.
- No calculation core files or stylesheets are included.
