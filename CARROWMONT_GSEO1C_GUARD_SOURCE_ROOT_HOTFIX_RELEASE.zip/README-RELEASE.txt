Carrowmont GSEO1C Multi-Repo Guard Source-Root Hotfix

Baseline: Snapshot 55
Scope: carrowmont-qa only
Changed file: scripts/source-contract.mjs

Reason:
Multi-Repo Guard checks production repositories under SOURCE_ROOT=.../tools but clones
carrowmont-qa separately at .../qa. The GSEO1C trust-page source contract was reading
carrowmont-qa/qa.config.js through SOURCE_ROOT, so it could not find qa.config.js in the
Guard layout even though the merged release itself was correct.

Fix:
Read qa.config.js relative to source-contract.mjs itself. This preserves Publisher
staging validation and makes the same contract valid in Multi-Repo Guard.

No workflow files or production website/calculator files are changed.
